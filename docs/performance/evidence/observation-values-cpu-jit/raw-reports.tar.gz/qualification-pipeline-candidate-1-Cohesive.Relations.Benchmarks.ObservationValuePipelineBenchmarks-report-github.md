```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload   | Mean           | Error       | StdDev      | Op/s        | Gen0     | Gen1    | Gen2    | Allocated  |
|------------ |----------- |---------------:|------------:|------------:|------------:|---------:|--------:|--------:|-----------:|
| **ParseDirect** | **collection** |    **31,058.8 ns** |   **830.83 ns** |   **434.54 ns** |    **32,196.9** |   **4.1667** |  **0.6127** |       **-** |   **34.17 KB** |
| **ParseDirect** | **flat**       |       **600.2 ns** |    **11.11 ns** |     **4.93 ns** | **1,666,155.1** |   **0.2003** |       **-** |       **-** |    **1.64 KB** |
| **ParseDirect** | **large**      | **1,270,671.2 ns** | **8,633.42 ns** | **4,515.45 ns** |       **787.0** | **115.3846** | **57.6923** | **43.2692** | **1004.35 KB** |
| **ParseDirect** | **nested**     |     **1,729.8 ns** |    **34.88 ns** |    **18.24 ns** |   **578,085.6** |   **0.5633** |  **0.0136** |       **-** |    **4.61 KB** |
