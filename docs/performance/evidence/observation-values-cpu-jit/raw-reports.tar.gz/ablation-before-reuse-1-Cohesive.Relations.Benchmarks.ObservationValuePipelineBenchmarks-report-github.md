```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload | Mean     | Error    | StdDev  | Op/s        | Gen0   | Allocated |
|------------ |--------- |---------:|---------:|--------:|------------:|-------:|----------:|
| ParseDirect | flat     | 550.0 ns | 13.98 ns | 7.31 ns | 1,818,157.0 | 0.1996 |   1.64 KB |
