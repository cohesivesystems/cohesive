```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload   | Mean           | Error        | StdDev      | Op/s        | Gen0     | Gen1    | Gen2    | Allocated  |
|------------ |----------- |---------------:|-------------:|------------:|------------:|---------:|--------:|--------:|-----------:|
| **ParseDirect** | **collection** |    **33,068.4 ns** |    **318.54 ns** |   **166.60 ns** |    **30,240.3** |   **4.0789** |  **0.5263** |       **-** |   **34.17 KB** |
| **ParseDirect** | **flat**       |       **606.5 ns** |     **10.22 ns** |     **4.54 ns** | **1,648,808.0** |   **0.2004** |       **-** |       **-** |    **1.64 KB** |
| **ParseDirect** | **large**      | **1,263,008.8 ns** | **14,670.60 ns** | **7,673.01 ns** |       **791.8** | **110.5769** | **52.8846** | **48.0769** | **1004.88 KB** |
| **ParseDirect** | **nested**     |     **1,751.6 ns** |     **10.38 ns** |     **4.61 ns** |   **570,922.2** |   **0.5585** |  **0.0141** |       **-** |    **4.61 KB** |
