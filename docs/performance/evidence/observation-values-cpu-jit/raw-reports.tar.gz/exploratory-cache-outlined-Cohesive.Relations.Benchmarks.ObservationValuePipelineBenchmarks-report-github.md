```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload   | Mean           | Error        | StdDev       | Op/s        | Gen0     | Gen1    | Gen2    | Allocated  |
|------------ |----------- |---------------:|-------------:|-------------:|------------:|---------:|--------:|--------:|-----------:|
| **ParseDirect** | **collection** |    **31,345.5 ns** |    **461.21 ns** |    **241.22 ns** |    **31,902.5** |   **4.1068** |  **0.5133** |       **-** |   **34.17 KB** |
| **ParseDirect** | **flat**       |       **589.6 ns** |      **9.73 ns** |      **5.09 ns** | **1,695,938.5** |   **0.1996** |       **-** |       **-** |    **1.64 KB** |
| **ParseDirect** | **large**      | **1,275,238.4 ns** | **21,758.94 ns** | **11,380.35 ns** |       **784.2** | **115.3846** | **57.6923** | **43.2692** | **1004.37 KB** |
| **ParseDirect** | **nested**     |     **1,676.7 ns** |     **41.68 ns** |     **21.80 ns** |   **596,401.1** |   **0.5627** |  **0.0136** |       **-** |    **4.61 KB** |
