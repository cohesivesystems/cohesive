```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload | Mean     | Error    | StdDev   | Op/s     | Gen0   | Gen1   | Gen2   | Allocated |
|------------ |--------- |---------:|---------:|---------:|---------:|-------:|-------:|-------:|----------:|
| ParseDirect | escaped  | 78.41 μs | 2.145 μs | 1.122 μs | 12,754.0 | 8.1917 | 1.8204 | 0.3034 |  67.43 KB |
