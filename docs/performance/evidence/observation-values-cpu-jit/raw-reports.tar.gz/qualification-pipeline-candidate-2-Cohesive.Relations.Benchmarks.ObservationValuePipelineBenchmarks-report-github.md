```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload   | Mean           | Error       | StdDev      | Op/s        | Gen0     | Gen1    | Gen2    | Allocated  |
|------------ |----------- |---------------:|------------:|------------:|------------:|---------:|--------:|--------:|-----------:|
| **ParseDirect** | **collection** |    **32,759.6 ns** |   **241.15 ns** |   **126.12 ns** |    **30,525.4** |   **4.0962** |  **0.5285** |       **-** |   **34.17 KB** |
| **ParseDirect** | **flat**       |       **607.1 ns** |    **12.59 ns** |     **6.58 ns** | **1,647,252.5** |   **0.1984** |       **-** |       **-** |    **1.64 KB** |
| **ParseDirect** | **large**      | **1,299,183.1 ns** | **8,840.44 ns** | **4,623.72 ns** |       **769.7** | **115.3846** | **57.6923** | **43.2692** | **1004.37 KB** |
| **ParseDirect** | **nested**     |     **1,741.0 ns** |    **76.72 ns** |    **40.12 ns** |   **574,390.8** |   **0.5634** |  **0.0139** |       **-** |    **4.61 KB** |
