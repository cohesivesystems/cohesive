```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload   | Mean           | Error        | StdDev      | Op/s        | Gen0     | Gen1    | Gen2    | Allocated  |
|------------ |----------- |---------------:|-------------:|------------:|------------:|---------:|--------:|--------:|-----------:|
| **ParseDirect** | **collection** |    **32,358.8 ns** |    **158.31 ns** |    **82.80 ns** |    **30,903.5** |   **4.1322** |  **0.5165** |       **-** |   **34.17 KB** |
| **ParseDirect** | **flat**       |       **608.6 ns** |      **2.54 ns** |     **1.13 ns** | **1,643,088.7** |   **0.1985** |       **-** |       **-** |    **1.64 KB** |
| **ParseDirect** | **large**      | **1,323,624.7 ns** | **12,767.61 ns** | **6,677.71 ns** |       **755.5** | **115.3846** | **57.6923** | **43.2692** | **1004.37 KB** |
| **ParseDirect** | **nested**     |     **1,813.7 ns** |     **82.49 ns** |    **43.14 ns** |   **551,354.2** |   **0.5601** |  **0.0144** |       **-** |    **4.61 KB** |
