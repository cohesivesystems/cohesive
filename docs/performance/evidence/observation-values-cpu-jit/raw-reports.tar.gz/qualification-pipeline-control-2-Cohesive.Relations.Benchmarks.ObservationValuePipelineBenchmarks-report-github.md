```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload   | Mean           | Error       | StdDev      | Op/s        | Gen0     | Gen1    | Gen2    | Allocated  |
|------------ |----------- |---------------:|------------:|------------:|------------:|---------:|--------:|--------:|-----------:|
| **ParseDirect** | **collection** |    **32,453.4 ns** |    **53.46 ns** |    **19.06 ns** |    **30,813.4** |   **4.1494** |  **0.5187** |       **-** |   **34.17 KB** |
| **ParseDirect** | **flat**       |       **610.2 ns** |     **3.46 ns** |     **1.81 ns** | **1,638,719.8** |   **0.2005** |       **-** |       **-** |    **1.64 KB** |
| **ParseDirect** | **large**      | **1,293,706.7 ns** | **6,081.27 ns** | **3,180.62 ns** |       **773.0** | **115.3846** | **57.6923** | **43.2692** | **1004.38 KB** |
| **ParseDirect** | **nested**     |     **1,733.7 ns** |    **30.66 ns** |    **16.04 ns** |   **576,791.7** |   **0.5601** |  **0.0140** |       **-** |    **4.61 KB** |
