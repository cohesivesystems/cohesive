```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload   | Mean           | Error        | StdDev       | Op/s        | Gen0     | Gen1    | Gen2    | Allocated  |
|------------ |----------- |---------------:|-------------:|-------------:|------------:|---------:|--------:|--------:|-----------:|
| **ParseDirect** | **collection** |    **32,953.8 ns** |    **185.61 ns** |     **82.41 ns** |    **30,345.5** |   **4.0704** |       **-** |       **-** |   **34.17 KB** |
| **ParseDirect** | **flat**       |       **597.9 ns** |      **3.49 ns** |      **1.55 ns** | **1,672,484.8** |   **0.2005** |  **0.0024** |       **-** |    **1.64 KB** |
| **ParseDirect** | **large**      | **1,307,563.5 ns** | **38,718.58 ns** | **17,191.29 ns** |       **764.8** | **115.3846** | **57.6923** | **43.2692** | **1004.39 KB** |
| **ParseDirect** | **nested**     |     **1,689.5 ns** |      **7.52 ns** |      **3.94 ns** |   **591,896.1** |   **0.5614** |  **0.0135** |       **-** |    **4.61 KB** |
