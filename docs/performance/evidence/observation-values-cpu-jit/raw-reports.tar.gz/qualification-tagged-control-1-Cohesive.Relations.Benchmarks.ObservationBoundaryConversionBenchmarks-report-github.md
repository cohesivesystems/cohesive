```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method         | Workload   | Mean           | Error       | StdDev      | Op/s        | Gen0     | Gen1    | Gen2    | Allocated  |
|--------------- |----------- |---------------:|------------:|------------:|------------:|---------:|--------:|--------:|-----------:|
| **DecodePortable** | **collection** |    **62,344.0 ns** |   **771.81 ns** |   **403.67 ns** |    **16,040.0** |   **4.4643** |  **0.2480** |       **-** |   **38.42 KB** |
| **DecodePortable** | **flat**       |       **943.3 ns** |     **6.19 ns** |     **3.24 ns** | **1,060,069.7** |   **0.1543** |       **-** |       **-** |    **1.28 KB** |
| **DecodePortable** | **large**      | **2,339,707.7 ns** | **7,578.64 ns** | **3,963.77 ns** |       **427.4** | **142.8571** | **80.3571** | **44.6429** | **1134.48 KB** |
| **DecodePortable** | **nested**     |     **2,681.7 ns** |    **19.58 ns** |    **10.24 ns** |   **372,895.8** |   **0.3977** |       **-** |       **-** |    **3.28 KB** |
