```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload | Mean     | Error    | StdDev   | Op/s        | Gen0   | Allocated |
|------------ |--------- |---------:|---------:|---------:|------------:|-------:|----------:|
| ParseDirect | flat     | 551.2 ns | 43.36 ns | 22.68 ns | 1,814,379.6 | 0.2001 |   1.64 KB |
