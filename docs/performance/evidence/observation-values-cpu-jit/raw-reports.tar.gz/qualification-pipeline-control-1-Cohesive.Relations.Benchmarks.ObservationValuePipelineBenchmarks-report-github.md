```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload   | Mean           | Error        | StdDev      | Op/s        | Gen0     | Gen1    | Gen2    | Allocated  |
|------------ |----------- |---------------:|-------------:|------------:|------------:|---------:|--------:|--------:|-----------:|
| **ParseDirect** | **collection** |    **31,734.9 ns** |    **435.02 ns** |   **155.13 ns** |    **31,511.0** |   **4.1416** |  **0.6275** |       **-** |   **34.17 KB** |
| **ParseDirect** | **flat**       |       **591.6 ns** |      **3.22 ns** |     **1.43 ns** | **1,690,312.1** |   **0.1995** |       **-** |       **-** |    **1.64 KB** |
| **ParseDirect** | **large**      | **1,264,765.0 ns** | **12,787.77 ns** | **5,677.85 ns** |       **790.7** | **115.3846** | **57.6923** | **43.2692** | **1004.36 KB** |
| **ParseDirect** | **nested**     |     **1,687.6 ns** |     **10.57 ns** |     **4.69 ns** |   **592,569.6** |   **0.5635** |  **0.0141** |       **-** |    **4.61 KB** |
