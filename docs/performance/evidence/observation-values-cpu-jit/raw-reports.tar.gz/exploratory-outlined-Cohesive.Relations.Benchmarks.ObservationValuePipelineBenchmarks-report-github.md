```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload   | Mean           | Error        | StdDev      | Op/s        | Gen0     | Gen1    | Gen2    | Allocated |
|------------ |----------- |---------------:|-------------:|------------:|------------:|---------:|--------:|--------:|----------:|
| **ParseDirect** | **collection** |    **32,910.3 ns** |    **288.29 ns** |   **150.78 ns** |    **30,385.6** |   **4.0876** |  **0.5274** |       **-** |  **34.17 KB** |
| **ParseDirect** | **flat**       |       **618.2 ns** |     **14.20 ns** |     **7.43 ns** | **1,617,468.9** |   **0.1989** |       **-** |       **-** |   **1.64 KB** |
| **ParseDirect** | **large**      | **1,307,491.9 ns** | **10,782.43 ns** | **4,787.47 ns** |       **764.8** | **115.3846** | **57.6923** | **43.2692** | **1004.4 KB** |
| **ParseDirect** | **nested**     |     **1,746.8 ns** |     **16.44 ns** |     **8.60 ns** |   **572,478.9** |   **0.5601** |  **0.0142** |       **-** |   **4.61 KB** |
