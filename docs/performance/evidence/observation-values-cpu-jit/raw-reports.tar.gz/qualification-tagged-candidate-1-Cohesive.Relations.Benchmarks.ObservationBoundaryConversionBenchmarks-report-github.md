```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method         | Workload   | Mean           | Error        | StdDev      | Op/s        | Gen0     | Gen1    | Gen2    | Allocated  |
|--------------- |----------- |---------------:|-------------:|------------:|------------:|---------:|--------:|--------:|-----------:|
| **DecodePortable** | **collection** |    **62,423.0 ns** |    **814.73 ns** |   **426.12 ns** |    **16,019.7** |   **4.4821** |  **0.2490** |       **-** |   **38.42 KB** |
| **DecodePortable** | **flat**       |       **954.4 ns** |     **18.89 ns** |     **8.39 ns** | **1,047,774.7** |   **0.1539** |       **-** |       **-** |    **1.28 KB** |
| **DecodePortable** | **large**      | **2,315,127.1 ns** | **14,054.42 ns** | **7,350.74 ns** |       **431.9** | **142.8571** | **80.3571** | **44.6429** | **1134.48 KB** |
| **DecodePortable** | **nested**     |     **2,632.2 ns** |     **13.14 ns** |     **6.87 ns** |   **379,907.2** |   **0.3973** |       **-** |       **-** |    **3.28 KB** |
