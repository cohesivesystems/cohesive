```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload | Mean     | Error    | StdDev   | Op/s     | Gen0   | Gen1   | Gen2   | Allocated |
|------------ |--------- |---------:|---------:|---------:|---------:|-------:|-------:|-------:|----------:|
| ParseDirect | escaped  | 75.40 μs | 1.220 μs | 0.638 μs | 13,262.1 | 8.1522 | 1.8116 | 0.3019 |  67.43 KB |
