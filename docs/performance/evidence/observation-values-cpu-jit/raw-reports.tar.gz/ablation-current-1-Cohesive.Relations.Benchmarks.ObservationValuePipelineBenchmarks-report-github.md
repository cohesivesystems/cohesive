```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload | Mean     | Error    | StdDev   | Op/s        | Gen0   | Allocated |
|------------ |--------- |---------:|---------:|---------:|------------:|-------:|----------:|
| ParseDirect | flat     | 570.1 ns | 22.52 ns | 11.78 ns | 1,754,007.0 | 0.2005 |   1.64 KB |
