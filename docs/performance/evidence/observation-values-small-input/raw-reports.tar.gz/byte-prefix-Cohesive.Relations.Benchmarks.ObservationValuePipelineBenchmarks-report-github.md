```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload   | Mean           | Error        | StdDev       | Op/s        | Gen0     | Gen1    | Gen2    | Allocated  |
|------------ |----------- |---------------:|-------------:|-------------:|------------:|---------:|--------:|--------:|-----------:|
| **ParseDirect** | **collection** |    **34,804.9 ns** |  **3,661.60 ns** |  **1,915.09 ns** |    **28,731.6** |   **4.0281** |  **0.5198** |       **-** |   **33.51 KB** |
| **ParseDirect** | **flat**       |       **594.3 ns** |      **9.62 ns** |      **5.03 ns** | **1,682,607.7** |   **0.1994** |       **-** |       **-** |    **1.64 KB** |
| **ParseDirect** | **large**      | **1,303,698.1 ns** | **28,666.24 ns** | **14,993.00 ns** |       **767.0** | **115.3846** | **57.6923** | **48.0769** | **1003.57 KB** |
| **ParseDirect** | **nested**     |     **1,715.6 ns** |     **33.33 ns** |     **17.43 ns** |   **582,883.8** |   **0.5616** |  **0.0137** |       **-** |    **4.61 KB** |
