```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload   | Mean           | Error        | StdDev       | Op/s        | Gen0     | Gen1    | Gen2    | Allocated  |
|------------ |----------- |---------------:|-------------:|-------------:|------------:|---------:|--------:|--------:|-----------:|
| **ParseDirect** | **collection** |    **30,560.5 ns** |    **466.41 ns** |    **243.94 ns** |    **32,722.0** |   **4.1182** |  **0.6056** |       **-** |   **34.17 KB** |
| **ParseDirect** | **flat**       |       **615.4 ns** |     **11.80 ns** |      **5.24 ns** | **1,625,020.3** |   **0.1999** |       **-** |       **-** |    **1.64 KB** |
| **ParseDirect** | **large**      | **1,318,411.9 ns** | **29,645.29 ns** | **13,162.69 ns** |       **758.5** | **114.5833** | **57.2917** | **46.8750** | **1005.12 KB** |
| **ParseDirect** | **nested**     |     **1,702.1 ns** |     **23.62 ns** |     **12.35 ns** |   **587,502.1** |   **0.5582** |  **0.0138** |       **-** |    **4.61 KB** |
