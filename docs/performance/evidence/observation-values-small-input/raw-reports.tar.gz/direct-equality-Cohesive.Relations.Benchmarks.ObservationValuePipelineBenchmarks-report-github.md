```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload   | Mean           | Error        | StdDev      | Op/s        | Gen0     | Gen1    | Gen2    | Allocated  |
|------------ |----------- |---------------:|-------------:|------------:|------------:|---------:|--------:|--------:|-----------:|
| **ParseDirect** | **collection** |    **32,882.3 ns** |    **516.33 ns** |   **270.05 ns** |    **30,411.5** |   **4.1580** |  **0.5198** |       **-** |   **34.17 KB** |
| **ParseDirect** | **flat**       |       **600.6 ns** |      **2.16 ns** |     **1.13 ns** | **1,665,137.7** |   **0.2002** |       **-** |       **-** |    **1.64 KB** |
| **ParseDirect** | **large**      | **1,304,788.7 ns** | **12,406.08 ns** | **6,488.62 ns** |       **766.4** | **115.3846** | **57.6923** | **43.2692** | **1004.41 KB** |
| **ParseDirect** | **nested**     |     **1,697.3 ns** |     **13.27 ns** |     **5.89 ns** |   **589,158.4** |   **0.5621** |  **0.0135** |       **-** |    **4.61 KB** |
