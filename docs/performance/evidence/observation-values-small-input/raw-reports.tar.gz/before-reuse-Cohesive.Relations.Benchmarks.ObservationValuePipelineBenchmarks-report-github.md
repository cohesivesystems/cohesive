```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload   | Mean           | Error        | StdDev       | Op/s        | Gen0     | Gen1     | Gen2    | Allocated  |
|------------ |----------- |---------------:|-------------:|-------------:|------------:|---------:|---------:|--------:|-----------:|
| **ParseDirect** | **collection** |    **30,190.5 ns** |    **584.67 ns** |    **305.80 ns** |    **33,123.0** |   **7.2206** |   **1.5388** |       **-** |   **59.15 KB** |
| **ParseDirect** | **flat**       |       **567.4 ns** |      **1.56 ns** |      **0.82 ns** | **1,762,465.4** |   **0.1986** |        **-** |       **-** |    **1.64 KB** |
| **ParseDirect** | **large**      | **1,645,024.1 ns** | **42,121.17 ns** | **22,030.18 ns** |       **607.9** | **232.9545** | **125.0000** | **90.9091** | **1904.32 KB** |
| **ParseDirect** | **nested**     |     **1,777.0 ns** |     **60.94 ns** |     **31.87 ns** |   **562,735.9** |   **0.5613** |   **0.0137** |       **-** |    **4.61 KB** |
