```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload   | Mean           | Error        | StdDev      | Op/s        | Gen0     | Gen1    | Gen2    | Allocated |
|------------ |----------- |---------------:|-------------:|------------:|------------:|---------:|--------:|--------:|----------:|
| **ParseDirect** | **collection** |    **32,627.9 ns** |    **218.47 ns** |    **97.00 ns** |    **30,648.6** |   **4.0704** |  **0.5252** |       **-** |  **34.17 KB** |
| **ParseDirect** | **flat**       |       **605.4 ns** |      **2.87 ns** |     **1.28 ns** | **1,651,906.6** |   **0.1999** |       **-** |       **-** |   **1.64 KB** |
| **ParseDirect** | **large**      | **1,297,545.6 ns** | **11,091.60 ns** | **5,801.12 ns** |       **770.7** | **115.3846** | **57.6923** | **43.2692** | **1004.4 KB** |
| **ParseDirect** | **nested**     |     **1,737.2 ns** |     **21.17 ns** |    **11.07 ns** |   **575,636.3** |   **0.5600** |  **0.0140** |       **-** |   **4.61 KB** |
