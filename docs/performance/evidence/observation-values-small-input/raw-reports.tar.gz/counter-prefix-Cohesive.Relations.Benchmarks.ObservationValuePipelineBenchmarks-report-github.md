```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method      | Workload   | Mean           | Error        | StdDev       | Op/s        | Gen0     | Gen1    | Gen2    | Allocated  |
|------------ |----------- |---------------:|-------------:|-------------:|------------:|---------:|--------:|--------:|-----------:|
| **ParseDirect** | **collection** |    **32,608.9 ns** |    **264.63 ns** |     **94.37 ns** |    **30,666.4** |   **4.0850** |  **0.5447** |       **-** |   **34.17 KB** |
| **ParseDirect** | **flat**       |       **624.3 ns** |     **22.91 ns** |     **11.98 ns** | **1,601,842.5** |   **0.1997** |       **-** |       **-** |    **1.64 KB** |
| **ParseDirect** | **large**      | **1,321,866.0 ns** | **23,956.56 ns** | **12,529.75 ns** |       **756.5** | **114.5833** | **57.2917** | **46.8750** | **1005.14 KB** |
| **ParseDirect** | **nested**     |     **1,920.4 ns** |    **100.84 ns** |     **52.74 ns** |   **520,734.1** |   **0.5585** |  **0.0143** |       **-** |    **4.61 KB** |
