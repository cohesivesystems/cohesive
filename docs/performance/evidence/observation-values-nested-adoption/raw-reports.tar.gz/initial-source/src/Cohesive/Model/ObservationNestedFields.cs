using System.Collections;

namespace Cohesive.Model;

// This view prevents a nested physical layout from claiming a root domain shape identity.
// Its storage is freshly owned/immutable; canonical traversal unwraps it without boxing.
internal sealed class ObservationNestedFields(IReadOnlyDictionary<string, ObservationValue> storage)
    : IReadOnlyDictionary<string, ObservationValue>
{
    internal IReadOnlyDictionary<string, ObservationValue> Storage => storage;
    public int Count => storage.Count;
    public IEnumerable<string> Keys => storage.Keys;
    public IEnumerable<ObservationValue> Values => storage.Values;
    public ObservationValue this[string key] => TryGetValue(key, out var value) ? value : throw new KeyNotFoundException(key);
    public bool ContainsKey(string key) => TryGetValue(key, out _);
    public bool TryGetValue(string key, out ObservationValue value)
    {
        ArgumentNullException.ThrowIfNull(key);
        if (string.IsNullOrWhiteSpace(key)) { value = default; return false; }
        return storage.TryGetValue(key, out value);
    }
    public IEnumerator<KeyValuePair<string, ObservationValue>> GetEnumerator() => storage.GetEnumerator();
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
