```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method           | Workload         | Mean     | Error    | StdDev   | Median   | Op/s    | Gen0    | Allocated |
|----------------- |----------------- |---------:|---------:|---------:|---------:|--------:|--------:|----------:|
| IngestAndProject | freight-case-128 | 150.6 μs | 239.7 μs | 85.50 μs | 98.26 μs | 6,640.4 | 15.0000 | 141.02 KB |
