```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method           | Workload    | Mean     | Error    | StdDev   | Median   | Op/s    | Gen0   | Allocated |
|----------------- |------------ |---------:|---------:|---------:|---------:|--------:|-------:|----------:|
| IngestAndProject | freight-128 | 147.2 μs | 226.6 μs | 80.82 μs | 106.9 μs | 6,792.8 | 8.6207 |  75.07 KB |
