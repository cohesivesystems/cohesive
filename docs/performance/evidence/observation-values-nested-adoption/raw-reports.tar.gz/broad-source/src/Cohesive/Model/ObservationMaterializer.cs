using System.Buffers;
using System.Collections.Concurrent;
using System.Linq.Expressions;
using System.Numerics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Text.Json.Serialization;
using Cohesive.Model.Serialization;

namespace Cohesive.Model;

/// <summary>Controls how observation materialization handles absent semantic fields.</summary>
public enum ObservationMissingFieldBehavior
{
    /// <summary>
    /// An absent mapped field causes materialization to fail unless its selected constructor parameter declares an
    /// explicit default value.
    /// </summary>
    Throw = 0,

    /// <summary>
    /// An absent field uses the target member's default value only for a nullable or reference type, or when a
    /// constructor parameter declares an explicit default value.
    /// </summary>
    UseDefaultForOptionalMembers = 1,

    /// <summary>Every absent mapped field uses the target member's default value.</summary>
    UseDefaultForAllMembers = 2
}

/// <summary>Reusable compiled interpretation from an identity-free observation to a CLR value.</summary>
/// <typeparam name="T">CLR target type.</typeparam>
/// <remarks>
/// A materializer is immutable and thread-safe. Its qualified shape identity, field mappings, converters,
/// serializer contract, missing-field policy, and optional ordinal layout are fixed when it is compiled.
/// </remarks>
public sealed class ObservationMaterializer<T>
{
    readonly Func<IObservationFieldReader, T> materialize;
    readonly ObservationLayout? ordinalLayout;
    readonly Func<IOrdinalObservationFieldReader, T>? materializeByOrdinal;
    readonly ObservationJsonIngestionPlan? jsonIngestion;

    internal ObservationMaterializer(
        QualifiedShapeId shapeId,
        Func<IObservationFieldReader, T> materialize,
        ObservationLayout? ordinalLayout = null,
        Func<IOrdinalObservationFieldReader, T>? materializeByOrdinal = null)
    {
        ShapeId = shapeId;
        this.materialize = Guard.RequireNotNull(materialize);
        this.ordinalLayout = ordinalLayout;
        this.materializeByOrdinal = materializeByOrdinal;
        jsonIngestion = ordinalLayout is null ? null : ObservationJsonIngestionPlan.Create(ordinalLayout);
    }

    /// <summary>Gets the exact graph-qualified shape accepted by this materializer.</summary>
    public QualifiedShapeId ShapeId { get; }

    /// <summary>
    /// Gets the exact shared layout bound to the ordinal fast path, or <see langword="null"/> for a name-only plan.
    /// </summary>
    public ObservationLayout? OrdinalLayout => ordinalLayout;

    /// <summary>Materializes a CLR value from an observation governed by <see cref="ShapeId"/>.</summary>
    /// <param name="observation">Identity-free observation to interpret.</param>
    /// <returns>The materialized CLR value.</returns>
    /// <exception cref="ArgumentNullException"><paramref name="observation"/> is <see langword="null"/>.</exception>
    /// <exception cref="InvalidOperationException">
    /// The observation has another qualified shape, a required mapped field is absent, conversion fails, or a
    /// converter returns null for a non-nullable target member.
    /// </exception>
    public T Materialize(Observation observation)
    {
        ArgumentNullException.ThrowIfNull(observation);
        return Materialize(observation.Fields is IOrdinalObservationFieldReader ordinalReader && ordinalReader.ShapeId == observation.ShapeId
            ? ordinalReader : observation);
    }

    /// <summary>Reads strict shape-bound JSON and materializes it through this plan's prebound ordinal mappings.</summary>
    /// <param name="utf8Json">One complete plain JSON object. Root names are exact-case layout identities;
    /// unknown or decoded duplicate root properties are rejected. Input bytes are borrowed only for this call.</param>
    /// <returns>A CLR value produced after complete shape admission. Owned value storage and the existing
    /// conversion, serializer and missing-member policies are used. Default mutable projections are independent;
    /// custom converters retain their existing contracts.</returns>
    /// <remarks>
    /// Compile with <see cref="ObservationMaterializerBuilder{T}.Compile(ObservationLayout)"/> first. The exact
    /// bound layout supplies the graph and ordinals. Validation covers the whole record, including unmapped
    /// fields, before any converter executes. This strict entry point does not change ordinary JSON conversion
    /// or the behavior of <see cref="Materialize(IObservationFieldReader)"/> on already validated readers.
    /// Serializer options configure CLR projection; they do not relax JSON shape admission. Nested record
    /// layouts and validation ordinals are prepared once at compilation. Exact names use owned ordinal
    /// storage; case variants and unknown nested members retain the original typed-reader semantics.
    /// These private physical layouts are never exposed as domain shape identities.
    /// </remarks>
    /// <exception cref="InvalidOperationException">The plan has no bound ordinal layout, a required mapped
    /// field is absent, conversion fails, or a converter returns null for a non-nullable target member.</exception>
    /// <exception cref="JsonException">Input is empty, malformed, has trailing non-whitespace content, is not an
    /// object, or contains unknown, wrong-case or decoded duplicate root names.</exception>
    /// <exception cref="ArgumentException">Parsed values fail the governing shape's semantic validation.</exception>
    public T MaterializeJson(ReadOnlySpan<byte> utf8Json)
    {
        if (ordinalLayout is null || materializeByOrdinal is null)
            throw new InvalidOperationException("Strict JSON materialization requires a plan compiled with an observation layout.");
        var layout = ordinalLayout;
        var shape = new GraphShapeId(layout.Graph, ShapeId.ShapeId);
        var values = new ObservationValue[layout.Count];
        var wordCount = layout.Count == 0 ? 0 : ((layout.Count - 1) >> 6) + 1;
        ulong[]? rented = null;
        Span<ulong> presence = wordCount <= 64
            ? stackalloc ulong[wordCount]
            : (rented = ArrayPool<ulong>.Shared.Rent(wordCount)).AsSpan(0, wordCount);
        try
        {
            if (!ObservationJsonReader.TryReadShape(utf8Json, shape, layout, values, presence, out var error, jsonIngestion))
                throw new ArgumentException($"JSON observation does not adhere to shape '{ShapeId}': {error}", nameof(utf8Json));
            var count = 0;
            foreach (var word in presence) count += BitOperations.PopCount(word);
            // Fresh values transfer once to the existing immutable reader. No dictionary, name lookup,
            // second validation pass or portable Observation wrapper is needed for this CLR interpretation.
            var fields = new OrdinalObservationFields(layout, ImmutableCollectionsMarshal.AsImmutableArray(values), count);
            return materializeByOrdinal(fields);
        }
        finally
        {
            if (rented is not null) ArrayPool<ulong>.Shared.Return(rented);
        }
    }

    /// <summary>Materializes a CLR value directly from a physical reader governed by <see cref="ShapeId"/>.</summary>
    /// <param name="reader">Validated physical interpretation of identity-free observation fields.</param>
    /// <returns>The materialized CLR value.</returns>
    /// <remarks>
    /// The reader is trusted to preserve validated core observation semantics. This method verifies exact qualified
    /// shape identity but does not revalidate the complete value tree.
    /// </remarks>
    /// <exception cref="ArgumentNullException"><paramref name="reader"/> is <see langword="null"/>.</exception>
    /// <exception cref="InvalidOperationException">
    /// The reader has another qualified shape, a required mapped field is absent, conversion fails, or a converter
    /// returns null for a non-nullable target member.
    /// </exception>
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public T Materialize(IObservationFieldReader reader)
    {
        ArgumentNullException.ThrowIfNull(reader);
        if (reader.ShapeId != ShapeId)
        {
            throw new InvalidOperationException(
                $"Materializer shape '{ShapeId}' does not match observation shape '{reader.ShapeId}'.");
        }

        return ordinalLayout is not null
            && materializeByOrdinal is not null
            && reader is IOrdinalObservationFieldReader ordinalReader
            && ReferenceEquals(ordinalReader.Layout, ordinalLayout)
                ? materializeByOrdinal(ordinalReader)
                : materialize(reader);
    }
}

/// <summary>Creates compiled observation-to-CLR materializers.</summary>
public static class ObservationMaterializer
{
    /// <summary>Prepares one CLR projection using the plain JSON contract of ObservationValue.Deserialize.</summary>
    /// <typeparam name="T">CLR result contract.</typeparam>
    /// <returns>A reusable thread-safe converter producing independent mutable CLR results. Explicitly
    /// immutable projections may be shared by their owning observation payload.</returns>
    /// <remarks>
    /// This interprets already-admitted portable values; it does not establish shape admission or cache results.
    /// Conventional scalar, array and constructor projections are compiled once. Customized JSON contracts and
    /// unsupported direct projections retain the existing JSON compatibility path. Casing and number policy
    /// remain plain serializer defaults, independently of the shape materializer's web defaults.
    /// </remarks>
    /// <exception cref="InvalidOperationException">A CLR projection cannot be prepared.</exception>
    public static Func<ObservationValue, T?> PrepareJsonValue<T>() =>
        DefaultObservationValueConverterCache.GetStrict(typeof(T)) is Func<ObservationValue, T?> prepared
            ? prepared : static value => value.Deserialize<T>();

    /// <summary>Prepares a CLR interpretation for one explicit frozen JSON profile.</summary>
    /// <typeparam name="T">CLR result contract.</typeparam>
    /// <param name="options">Read-only serializer options retained by the returned converter; never modified.</param>
    /// <param name="bytesEncoding">Policy for projecting binary values into compatibility JSON.</param>
    /// <returns>A reusable converter, shareable under the supplied profile's converter/constructor contracts.
    /// Mutable results remain independent; existing immutable
    /// interpretation reuse follows the exact payload, profile and binary policy.</returns>
    /// <remarks>Prepare at registration and retain the delegate. Conventional exact-name objects, arrays and
    /// scalars read directly. Custom metadata, converters, naming, case variants and unsupported contracts retain
    /// serializer behavior through local compatibility paths. This does not establish semantic admission.</remarks>
    /// <exception cref="ArgumentNullException"><paramref name="options"/> is null.</exception>
    /// <exception cref="ArgumentException"><paramref name="options"/> is mutable.</exception>
    /// <exception cref="ArgumentOutOfRangeException"><paramref name="bytesEncoding"/> is unsupported.</exception>
    /// <exception cref="InvalidOperationException">The CLR interpretation cannot be prepared.</exception>
    /// <exception cref="NotSupportedException">Serializer metadata for the target type is unavailable.</exception>
    public static Func<ObservationValue, T?> PrepareJsonValue<T>(JsonSerializerOptions options,
        ObservationBytesJsonEncoding bytesEncoding = ObservationBytesJsonEncoding.Throw)
    {
        ArgumentNullException.ThrowIfNull(options);
        if (!options.IsReadOnly) throw new ArgumentException("A prepared JSON profile must be read-only.", nameof(options));
        if (!Enum.IsDefined(bytesEncoding)) throw new ArgumentOutOfRangeException(nameof(bytesEncoding));
        if (DefaultObservationValueConverterCache.PrepareJsonProfile(typeof(T), options, bytesEncoding) is not Func<ObservationValue, T?> prepared)
            return value => value.Deserialize<T>(options, bytesEncoding);
        var maxDepth = options.MaxDepth == 0 ? DefaultObservationValueConverterCache.JsonProjectionDepthLimit
            : Math.Min(options.MaxDepth, DefaultObservationValueConverterCache.JsonProjectionDepthLimit);
        return value => DefaultObservationValueConverterCache.CanProjectJson(value, maxDepth, bytesEncoding)
            ? prepared(value) : value.Deserialize<T>(options, bytesEncoding);
    }

    /// <summary>Creates a configurable materializer builder for an exact graph-scoped shape.</summary>
    /// <typeparam name="T">CLR target type.</typeparam>
    /// <param name="shape">Exact graph and shape accepted by the compiled materializer.</param>
    /// <returns>A builder using explicit JSON property names when declared, otherwise CLR property names.</returns>
    /// <exception cref="ArgumentNullException"><paramref name="shape"/> is default.</exception>
    public static ObservationMaterializerBuilder<T> For<T>(GraphShapeId shape)
    {
        ArgumentNullException.ThrowIfNull(shape.Graph);
        return new(shape.QualifiedId);
    }

    /// <summary>Creates a configurable materializer builder from an already resolved qualified shape identity.</summary>
    /// <typeparam name="T">CLR target type.</typeparam>
    /// <param name="shapeId">Exact graph-qualified shape accepted by the compiled materializer.</param>
    /// <returns>A builder using explicit JSON property names when declared, otherwise CLR property names.</returns>
    /// <remarks>
    /// Use this overload when a compiler or physical interpreter has already resolved and validated shape evidence.
    /// The materializer binds that identity but does not require or retain a mutable graph object.
    /// </remarks>
    /// <exception cref="ArgumentException"><paramref name="shapeId"/> is default.</exception>
    public static ObservationMaterializerBuilder<T> For<T>(QualifiedShapeId shapeId)
    {
        if (string.IsNullOrWhiteSpace(shapeId.GraphId.Value) || string.IsNullOrWhiteSpace(shapeId.ShapeId.Value))
            throw new ArgumentException("A materializer requires a graph-qualified shape identity.", nameof(shapeId));

        return new(shapeId);
    }

    /// <summary>
    /// Gets the cached default materializer for a target CLR type and an observation's exact qualified shape.
    /// </summary>
    /// <typeparam name="T">CLR target type.</typeparam>
    /// <param name="observation">Observation providing qualified shape evidence.</param>
    /// <returns>
    /// A process-wide reusable materializer using explicit JSON property names (otherwise CLR names), web JSON conversion with string enums, and
    /// optional-member defaults.
    /// </returns>
    /// <remarks>
    /// Cache identity includes <typeparamref name="T"/> through the generic cache and the complete
    /// <see cref="QualifiedShapeId"/> through its key. It never depends on a local shape id or a physical layout.
    /// </remarks>
    /// <exception cref="ArgumentNullException"><paramref name="observation"/> is <see langword="null"/>.</exception>
    public static ObservationMaterializer<T> GetDefault<T>(Observation observation)
    {
        ArgumentNullException.ThrowIfNull(observation);
        return DefaultObservationMaterializerCache<T>.Get(observation.ShapeId);
    }

    /// <summary>
    /// Gets the cached default materializer for a target CLR type and a physical observation reader's exact shape.
    /// </summary>
    /// <typeparam name="T">CLR target type.</typeparam>
    /// <param name="reader">Physical reader providing qualified shape evidence.</param>
    /// <returns>
    /// A process-wide reusable materializer using explicit JSON property names (otherwise CLR names), web JSON conversion with string enums, and
    /// optional-member defaults.
    /// </returns>
    /// <remarks>
    /// The reader is an execution interpretation; this operation does not make it a semantic observation authority.
    /// </remarks>
    /// <exception cref="ArgumentNullException"><paramref name="reader"/> is <see langword="null"/>.</exception>
    public static ObservationMaterializer<T> GetDefault<T>(IObservationFieldReader reader)
    {
        ArgumentNullException.ThrowIfNull(reader);
        return DefaultObservationMaterializerCache<T>.Get(reader.ShapeId);
    }
}

/// <summary>Builds an immutable compiled observation-to-CLR materializer.</summary>
/// <typeparam name="T">CLR target type.</typeparam>
/// <remarks>
/// This builder is mutable and is intended for single-threaded authoring before <see cref="Compile()"/>. The framework
/// default serializer contract compiles canonical scalar, array, and immutable constructor-object reads directly.
/// Customized or unsupported JSON contracts retain the serializer compatibility path.
/// </remarks>
public sealed class ObservationMaterializerBuilder<T>
{
    readonly QualifiedShapeId shapeId;
    readonly List<PropertyMapping> mappings = [];
    JsonSerializerOptions serializerOptions = ObservationMaterializerDefaults.SerializerOptions;
    ObservationMissingFieldBehavior missingFieldBehavior =
        ObservationMissingFieldBehavior.UseDefaultForOptionalMembers;
    ClrShapeGraphBuildResult? clrShapeMetadata;
    Func<PropertyInfo, string> implicitFieldIdentity = Authoring.DefaultClrTypeRefMapper.GetSerializedMemberName;

    internal ObservationMaterializerBuilder(QualifiedShapeId shapeId) => this.shapeId = shapeId;

    /// <summary>Maps a semantic field identity to a target CLR property.</summary>
    /// <typeparam name="TValue">Target property type.</typeparam>
    /// <param name="fieldIdentity">Canonical top-level semantic field identity.</param>
    /// <param name="target">Direct target property selector, such as <c>value =&gt; value.Name</c>.</param>
    /// <returns>This builder for continued configuration.</returns>
    /// <exception cref="ArgumentNullException"><paramref name="fieldIdentity"/> or <paramref name="target"/> is null.</exception>
    /// <exception cref="ArgumentException"><paramref name="fieldIdentity"/> is empty.</exception>
    /// <exception cref="InvalidOperationException"><paramref name="target"/> is not a direct property access.</exception>
    public ObservationMaterializerBuilder<T> Map<TValue>(
        string fieldIdentity,
        Expression<Func<T, TValue>> target) =>
        Map(fieldIdentity, target, convert: null);

    /// <summary>Maps and converts a semantic field value to a target CLR property.</summary>
    /// <typeparam name="TValue">Target property type.</typeparam>
    /// <param name="fieldIdentity">Canonical top-level semantic field identity.</param>
    /// <param name="target">Direct target property selector, such as <c>value =&gt; value.Name</c>.</param>
    /// <param name="convert">
    /// Optional field converter. When omitted, the immutable observation value is interpreted using the effective
    /// serializer contract. The framework default may use an equivalent direct conversion for canonical values.
    /// </param>
    /// <returns>This builder for continued configuration.</returns>
    /// <exception cref="ArgumentNullException"><paramref name="fieldIdentity"/> or <paramref name="target"/> is null.</exception>
    /// <exception cref="ArgumentException"><paramref name="fieldIdentity"/> is empty.</exception>
    /// <exception cref="InvalidOperationException"><paramref name="target"/> is not a direct property access.</exception>
    public ObservationMaterializerBuilder<T> Map<TValue>(
        string fieldIdentity,
        Expression<Func<T, TValue>> target,
        Func<ObservationValue, TValue>? convert)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(fieldIdentity);
        ArgumentNullException.ThrowIfNull(target);
        mappings.Add(new(ResolveTargetProperty(target), fieldIdentity, convert));
        return this;
    }

    /// <summary>Maps every readable target property using a caller-supplied semantic field-identity convention.</summary>
    /// <param name="resolveFieldIdentity">Resolves one non-empty canonical field identity per readable property.</param>
    /// <returns>This builder for continued configuration.</returns>
    /// <remarks>
    /// These mappings are explicit and therefore take precedence over CLR shape metadata or the implicit convention.
    /// Use <see cref="WithImplicitFieldIdentityConvention"/> when only unmapped properties should use a convention.
    /// </remarks>
    /// <exception cref="ArgumentNullException">
    /// <paramref name="resolveFieldIdentity"/> is <see langword="null"/>.
    /// </exception>
    /// <exception cref="ArgumentException">A resolved field identity is empty or white-space.</exception>
    public ObservationMaterializerBuilder<T> MapAll(Func<PropertyInfo, string> resolveFieldIdentity)
    {
        ArgumentNullException.ThrowIfNull(resolveFieldIdentity);
        foreach (var property in ObservationMaterializerTypeCache<T>.ReadableProperties)
        {
            var fieldIdentity = resolveFieldIdentity(property);
            ArgumentException.ThrowIfNullOrWhiteSpace(fieldIdentity);
            mappings.Add(new(property, fieldIdentity, Converter: null));
        }

        return this;
    }

    /// <summary>Sets the field-identity convention used for readable properties without explicit mappings.</summary>
    /// <param name="resolveFieldIdentity">Resolves one non-empty canonical field identity per readable property.</param>
    /// <returns>This builder for continued configuration.</returns>
    /// <remarks>Effective CLR shape metadata, when supplied, takes precedence over this fallback convention.</remarks>
    /// <exception cref="ArgumentNullException">
    /// <paramref name="resolveFieldIdentity"/> is <see langword="null"/>.
    /// </exception>
    public ObservationMaterializerBuilder<T> WithImplicitFieldIdentityConvention(
        Func<PropertyInfo, string> resolveFieldIdentity)
    {
        implicitFieldIdentity = Guard.RequireNotNull(resolveFieldIdentity);
        return this;
    }

    /// <summary>
    /// Uses effective CLR field identities from the immutable result produced by <see cref="ClrShapeGraphBuilder"/>.
    /// </summary>
    /// <param name="metadata">
    /// Immutable graph-build result whose root mapping for <typeparamref name="T"/> must identify this
    /// materializer's exact graph and shape.
    /// </param>
    /// <returns>This builder for continued configuration.</returns>
    /// <remarks>Explicit mappings configured with <see cref="Map{TValue}(string, Expression{Func{T, TValue}})"/> take precedence.</remarks>
    /// <exception cref="ArgumentNullException"><paramref name="metadata"/> is <see langword="null"/>.</exception>
    public ObservationMaterializerBuilder<T> WithClrShapeMetadata(ClrShapeGraphBuildResult metadata)
    {
        clrShapeMetadata = Guard.RequireNotNull(metadata);
        return this;
    }

    /// <summary>Sets serializer options used by default field conversions.</summary>
    /// <param name="options">Serializer contract to snapshot when <see cref="Compile()"/> is called.</param>
    /// <returns>This builder for continued configuration.</returns>
    /// <remarks>Compilation clones and freezes the options; later caller mutation cannot change the materializer.</remarks>
    /// <exception cref="ArgumentNullException"><paramref name="options"/> is <see langword="null"/>.</exception>
    public ObservationMaterializerBuilder<T> WithSerializerOptions(JsonSerializerOptions options)
    {
        serializerOptions = Guard.RequireNotNull(options);
        return this;
    }

    /// <summary>Sets the policy used when a mapped semantic field is absent.</summary>
    /// <param name="behavior">Missing-field policy fixed into the compiled materializer.</param>
    /// <returns>This builder for continued configuration.</returns>
    /// <exception cref="ArgumentOutOfRangeException"><paramref name="behavior"/> is not defined.</exception>
    public ObservationMaterializerBuilder<T> WithMissingFieldBehavior(ObservationMissingFieldBehavior behavior)
    {
        if (!Enum.IsDefined(behavior))
            throw new ArgumentOutOfRangeException(nameof(behavior), behavior, "Unknown missing-field behavior.");

        missingFieldBehavior = behavior;
        return this;
    }

    /// <summary>Compiles the configured mappings into an immutable reusable materializer.</summary>
    /// <returns>A thread-safe materializer bound to the exact qualified shape.</returns>
    /// <exception cref="InvalidOperationException">
    /// Mappings are empty, duplicated, cannot satisfy a constructor, leave a property unsettable, or supplied CLR
    /// metadata does not identify this target type and exact qualified shape.
    /// </exception>
    public ObservationMaterializer<T> Compile()
        => CompileCore(ordinalLayout: null);

    /// <summary>
    /// Compiles the configured mappings with an ordinal-specialized path for one exact shared physical layout.
    /// </summary>
    /// <param name="layout">
    /// Immutable layout to bind into the compiled plan. Readers must expose this exact instance to use ordinal reads.
    /// </param>
    /// <returns>
    /// A thread-safe materializer with an ordinal fast path and a name-based fallback for semantic observations or
    /// readers using another layout.
    /// </returns>
    /// <remarks>
    /// Binding is performed once during compilation. Runtime materialization selects the ordinal path with a
    /// reference comparison and never performs per-field name lookup when the layout matches.
    /// </remarks>
    /// <exception cref="ArgumentNullException"><paramref name="layout"/> is <see langword="null"/>.</exception>
    /// <exception cref="ArgumentException"><paramref name="layout"/> targets another qualified shape.</exception>
    /// <exception cref="InvalidOperationException">
    /// Mappings are empty, duplicated, absent from the layout, cannot satisfy a constructor, leave a property
    /// unsettable, or supplied CLR metadata does not identify this target type and exact qualified shape.
    /// </exception>
    public ObservationMaterializer<T> Compile(ObservationLayout layout)
    {
        ArgumentNullException.ThrowIfNull(layout);
        if (layout.ShapeId != shapeId)
        {
            throw new ArgumentException(
                $"Materializer shape '{shapeId}' does not match layout shape '{layout.ShapeId}'.",
                nameof(layout));
        }

        return CompileCore(layout);
    }

    ObservationMaterializer<T> CompileCore(ObservationLayout? ordinalLayout)
    {
        var effectiveMappings = BuildEffectiveMappings(ObservationMaterializerTypeCache<T>.ReadableProperties);
        if (effectiveMappings.Count == 0)
            throw new InvalidOperationException($"Materializer for '{typeof(T).Name}' must define at least one field mapping.");

        var duplicateProperty = effectiveMappings.TryGetDuplicateByKey(
            static mapping => mapping.Property.Name,
            StringComparer.OrdinalIgnoreCase);
        if (duplicateProperty is not null)
        {
            throw new InvalidOperationException(
                $"Materializer for '{typeof(T).Name}' contains duplicate property mapping '{duplicateProperty.Property.Name}'.");
        }

        var duplicateField = effectiveMappings.TryGetDuplicateByKey(
            static mapping => mapping.FieldIdentity,
            StringComparer.Ordinal);
        if (duplicateField is not null)
        {
            throw new InvalidOperationException(
                $"Materializer for '{typeof(T).Name}' contains duplicate field mapping '{duplicateField.FieldIdentity}'.");
        }

        var byProperty = effectiveMappings.ToDictionary(
            static mapping => mapping.Property.Name,
            StringComparer.OrdinalIgnoreCase);
        var constructor = SelectConstructor(byProperty);
        var useDefaultValueConverters = ReferenceEquals(
            serializerOptions,
            ObservationMaterializerDefaults.SerializerOptions);
        var frozenSerializerOptions = ObservationMaterializerDefaults.Snapshot(serializerOptions);
        var compiled = CompileMaterializer<IObservationFieldReader>(
            constructor,
            byProperty,
            effectiveMappings,
            frozenSerializerOptions,
            useDefaultValueConverters,
            ordinalLayout: null);
        var compiledByOrdinal = ordinalLayout is null
            ? null
            : CompileMaterializer<IOrdinalObservationFieldReader>(
                constructor,
                byProperty,
                effectiveMappings,
                frozenSerializerOptions,
                useDefaultValueConverters,
                ordinalLayout);
        return new(shapeId, compiled, ordinalLayout, compiledByOrdinal);
    }

    IReadOnlyList<PropertyMapping> BuildEffectiveMappings(IReadOnlyList<PropertyInfo> readableProperties)
    {
        ValidateClrShapeMetadata();

        Dictionary<string, PropertyMapping> explicitByProperty = new(StringComparer.OrdinalIgnoreCase);
        foreach (var mapping in mappings)
        {
            if (!explicitByProperty.TryAdd(mapping.Property.Name, mapping))
            {
                throw new InvalidOperationException(
                    $"Materializer for '{typeof(T).Name}' contains duplicate property mapping '{mapping.Property.Name}'.");
            }
        }

        List<PropertyMapping> effective = [];
        HashSet<string> knownProperties = new(StringComparer.OrdinalIgnoreCase);
        foreach (var property in readableProperties)
        {
            knownProperties.Add(property.Name);
            if (explicitByProperty.TryGetValue(property.Name, out var mapping))
            {
                effective.Add(mapping);
                continue;
            }

            effective.Add(new(property, ResolveImplicitFieldIdentity(property), Converter: null));
        }

        foreach (var mapping in explicitByProperty.Values.Where(mapping => !knownProperties.Contains(mapping.Property.Name)))
            effective.Add(mapping);

        return effective;
    }

    void ValidateClrShapeMetadata()
    {
        if (clrShapeMetadata is null)
            return;

        if (clrShapeMetadata.Graph.Id != shapeId.GraphId)
        {
            throw new InvalidOperationException(
                $"CLR shape metadata graph '{clrShapeMetadata.Graph.Id.Value}' does not match materializer graph '{shapeId.GraphId.Value}'.");
        }

        if (!clrShapeMetadata.ShapeIds.TryGetValue(typeof(T), out var metadataShapeId))
        {
            throw new InvalidOperationException(
                $"CLR shape metadata does not contain root target type '{typeof(T).FullName}'.");
        }

        if (metadataShapeId != shapeId.ShapeId)
        {
            throw new InvalidOperationException(
                $"CLR shape metadata maps target type '{typeof(T).FullName}' to shape '{metadataShapeId.Value}', not materializer shape '{shapeId.ShapeId.Value}'.");
        }
    }

    string ResolveImplicitFieldIdentity(PropertyInfo property)
    {
        if (clrShapeMetadata is null)
        {
            var fieldIdentity = implicitFieldIdentity(property);
            if (string.IsNullOrWhiteSpace(fieldIdentity))
            {
                throw new InvalidOperationException(
                    $"Field-identity convention returned an empty identity for property '{property.Name}' on '{typeof(T).Name}'.");
            }

            return fieldIdentity;
        }

        var path = clrShapeMetadata.ResolveMemberPath(typeof(T), [property]);
        return path.Segments[0].Segment!;
    }

    static ConstructorInfo? SelectConstructor(IReadOnlyDictionary<string, PropertyMapping> byProperty)
    {
        var candidates = ObservationMaterializerTypeCache<T>.PublicConstructors
            .Where(constructor => constructor.GetParameters().All(
                parameter => byProperty.ContainsKey(parameter.Name ?? string.Empty)))
            .OrderByDescending(static constructor => constructor.GetParameters().Length)
            .ToArray();

        if (candidates.Length == 0)
        {
            if (typeof(T).IsValueType || ObservationMaterializerTypeCache<T>.DefaultConstructor is not null)
                return null;

            throw new InvalidOperationException(
                $"No public constructor on '{typeof(T).Name}' can be satisfied by mapped properties.");
        }

        var maximumArity = candidates[0].GetParameters().Length;
        var maximumArityCandidates = candidates
            .Where(constructor => constructor.GetParameters().Length == maximumArity)
            .ToArray();
        if (maximumArityCandidates.Length > 1)
        {
            throw new InvalidOperationException(
                $"Multiple constructors on '{typeof(T).Name}' are ambiguous for mapped properties.");
        }

        return maximumArityCandidates[0];
    }

    Func<TReader, T> CompileMaterializer<TReader>(
        ConstructorInfo? constructor,
        IReadOnlyDictionary<string, PropertyMapping> byProperty,
        IReadOnlyList<PropertyMapping> effectiveMappings,
        JsonSerializerOptions frozenSerializerOptions,
        bool useDefaultValueConverters,
        ObservationLayout? ordinalLayout)
        where TReader : IObservationFieldReader
    {
        var observation = Expression.Parameter(typeof(TReader), "observation");
        var options = Expression.Constant(frozenSerializerOptions);
        var constructorParameters = constructor?.GetParameters() ?? [];
        var constructorArguments = constructorParameters
            .Select(parameter =>
            {
                var mapping = byProperty[parameter.Name ?? string.Empty];
                return BuildReadExpression(
                    observation,
                    mapping,
                    parameter.ParameterType,
                    options,
                    useDefaultValueConverters,
                    ordinalLayout,
                    ResolveMissingField(
                        parameter.ParameterType,
                        parameter.HasDefaultValue,
                        parameter.HasDefaultValue ? parameter.DefaultValue : null));
            })
            .ToArray();

        var creation = constructor is null
            ? Expression.New(typeof(T))
            : Expression.New(constructor, constructorArguments);
        var constructorProperties = constructorParameters
            .Select(static parameter => parameter.Name ?? string.Empty)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var additionalBindings = effectiveMappings
            .Where(mapping => !constructorProperties.Contains(mapping.Property.Name))
            .Select(mapping =>
            {
                if (mapping.Property.SetMethod is null)
                {
                    throw new InvalidOperationException(
                        $"Property '{mapping.Property.Name}' on '{typeof(T).Name}' is not settable and is not in the selected constructor.");
                }

                return Expression.Bind(
                    mapping.Property,
                    BuildReadExpression(
                        observation,
                        mapping,
                        mapping.Property.PropertyType,
                        options,
                        useDefaultValueConverters,
                        ordinalLayout,
                        ResolveMissingField(mapping.Property.PropertyType)));
            })
            .ToArray();

        Expression body = additionalBindings.Length == 0
            ? creation
            : Expression.MemberInit(creation, additionalBindings);
        return Expression.Lambda<Func<TReader, T>>(body, observation).Compile();
    }

    Expression BuildReadExpression(
        ParameterExpression observation,
        PropertyMapping mapping,
        Type targetType,
        ConstantExpression serializerOptions,
        bool useDefaultValueConverters,
        ObservationLayout? ordinalLayout,
        MissingFieldResolution missingFieldResolution)
    {
        var converter = mapping.Converter;
        if (converter is null && useDefaultValueConverters)
        {
            converter = DefaultObservationValueConverterCache.Get(targetType);
        }

        if (ordinalLayout is null)
        {
            return Expression.Call(
                ObservationMaterializerTypeCache<T>.ReadMappedValueMethod.MakeGenericMethod(targetType),
                observation,
                Expression.Constant(converter, typeof(Delegate)),
                serializerOptions,
                Expression.Constant(mapping.FieldIdentity),
                Expression.Constant(missingFieldResolution));
        }

        if (!ordinalLayout.TryGetOrdinal(mapping.FieldIdentity, out var ordinal))
        {
            throw new InvalidOperationException(
                $"Materializer field '{mapping.FieldIdentity}' is absent from layout '{ordinalLayout}'.");
        }

        var fieldIdentity = Expression.Constant(mapping.FieldIdentity);
        if (targetType == typeof(byte[]) && mapping.Converter is null && useDefaultValueConverters
            && ordinalLayout.GetFieldDefinition(ordinal) is
            { Type: ScalarTypeRef { Kind: ScalarTypeKind.Bytes }, Cardinality: FieldCardinality.Single })
        {
            var bytes = Expression.Variable(typeof(byte[]), "bytes");
            return Expression.Block(
                [bytes],
                Expression.Condition(
                    Expression.Call(observation, ObservationMaterializerTypeCache<T>.TryGetBytesByOrdinalMethod,
                        Expression.Constant(ordinal), bytes),
                    bytes,
                    Expression.Call(
                        ObservationMaterializerTypeCache<T>.ResolveMissingValueMethod.MakeGenericMethod(targetType),
                        observation, fieldIdentity, Expression.Constant(missingFieldResolution))));
        }

        var observed = Expression.Variable(typeof(ObservationValue), "observed");
        return Expression.Block(
            [observed],
            Expression.Condition(
                Expression.Call(
                    observation,
                    ObservationMaterializerTypeCache<T>.TryGetFieldByOrdinalMethod,
                    Expression.Constant(ordinal),
                    observed),
                Expression.Call(
                    ObservationMaterializerTypeCache<T>.ConvertObservedValueMethod.MakeGenericMethod(targetType),
                    observed,
                    Expression.Constant(converter, typeof(Delegate)),
                    serializerOptions,
                    fieldIdentity),
                Expression.Call(
                    ObservationMaterializerTypeCache<T>.ResolveMissingValueMethod.MakeGenericMethod(targetType),
                    observation,
                    fieldIdentity,
                    Expression.Constant(missingFieldResolution))));
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    static TValue ReadMappedValue<TValue>(
        IObservationFieldReader observation,
        Delegate? converter,
        JsonSerializerOptions serializerOptions,
        string fieldIdentity,
        MissingFieldResolution missingFieldResolution)
    {
        if (!observation.TryGetField(fieldIdentity, out var observed))
            return ResolveMissingValue<TValue>(observation, fieldIdentity, missingFieldResolution);

        return ConvertObservedValue<TValue>(observed, converter, serializerOptions, fieldIdentity);
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    static TValue ConvertObservedValue<TValue>(
        ObservationValue observed,
        Delegate? converter,
        JsonSerializerOptions serializerOptions,
        string fieldIdentity)
    {
        if (converter is Func<ObservationValue, TValue> typedConverter)
            return EnsureNonNull(typedConverter(observed), fieldIdentity);

        if (converter is not null)
        {
            throw new InvalidOperationException(
                $"Field '{fieldIdentity}' uses unsupported converter type '{converter.GetType().Name}' for target '{typeof(TValue).Name}'.");
        }

        return EnsureNonNull(observed.Deserialize<TValue>(serializerOptions), fieldIdentity);
    }

    static TValue EnsureNonNull<TValue>(TValue? value, string fieldIdentity)
    {
        if (value is null && default(TValue) is not null)
        {
            throw new InvalidOperationException(
                $"Field '{fieldIdentity}' converted to null for non-nullable target type '{typeof(TValue).Name}'.");
        }

        return value!;
    }

    MissingFieldResolution ResolveMissingField(
        Type targetType,
        bool hasExplicitDefault = false,
        object? explicitDefault = null)
    {
        if (hasExplicitDefault)
            return new(MissingFieldResolutionKind.UseExplicitDefaultValue, explicitDefault);

        return missingFieldBehavior switch
        {
            ObservationMissingFieldBehavior.Throw => MissingFieldResolution.Throw,
            ObservationMissingFieldBehavior.UseDefaultForAllMembers => MissingFieldResolution.UseTypeDefault,
            ObservationMissingFieldBehavior.UseDefaultForOptionalMembers when CanUseTypeDefault(targetType) =>
                MissingFieldResolution.UseTypeDefault,
            _ => MissingFieldResolution.Throw
        };
    }

    static bool CanUseTypeDefault(Type targetType) =>
        !targetType.IsValueType || Nullable.GetUnderlyingType(targetType) is not null;

    static TValue ResolveMissingValue<TValue>(
        IObservationFieldReader observation,
        string fieldIdentity,
        MissingFieldResolution resolution) =>
        resolution.Kind switch
        {
            MissingFieldResolutionKind.UseTypeDefault => default!,
            MissingFieldResolutionKind.UseExplicitDefaultValue when resolution.ExplicitDefaultValue is TValue value => value,
            MissingFieldResolutionKind.UseExplicitDefaultValue => (TValue)resolution.ExplicitDefaultValue!,
            _ => throw new InvalidOperationException(
                $"Observation '{observation.ShapeId}' is missing required field '{fieldIdentity}'.")
        };

    static PropertyInfo ResolveTargetProperty<TValue>(Expression<Func<T, TValue>> target)
    {
        Expression body = target.Body;
        if (body is UnaryExpression
            {
                NodeType: ExpressionType.Convert or ExpressionType.ConvertChecked
            } unary)
        {
            body = unary.Operand;
        }

        if (body is not MemberExpression
            {
                Member: PropertyInfo property,
                Expression: ParameterExpression parameter
            }
            || !ReferenceEquals(parameter, target.Parameters[0]))
        {
            throw new InvalidOperationException(
                "Target selector must be a direct property access like 'value => value.Property'.");
        }

        return property;
    }

    sealed record PropertyMapping(PropertyInfo Property, string FieldIdentity, Delegate? Converter);

    readonly record struct MissingFieldResolution(
        MissingFieldResolutionKind Kind,
        object? ExplicitDefaultValue = null)
    {
        public static MissingFieldResolution Throw => new(MissingFieldResolutionKind.Throw);

        public static MissingFieldResolution UseTypeDefault => new(MissingFieldResolutionKind.UseTypeDefault);
    }

    enum MissingFieldResolutionKind
    {
        Throw = 0,
        UseTypeDefault = 1,
        UseExplicitDefaultValue = 2
    }
}

static class ObservationMaterializerDefaults
{
    public static JsonSerializerOptions SerializerOptions { get; } = CreateSerializerOptions();

    public static JsonSerializerOptions Snapshot(JsonSerializerOptions options)
    {
        JsonSerializerOptions snapshot = new(options);
        snapshot.MakeReadOnly(populateMissingResolver: true);
        return snapshot;
    }

    static JsonSerializerOptions CreateSerializerOptions()
    {
        JsonSerializerOptions options = new(JsonSerializerDefaults.Web);
        options.Converters.Add(new JsonStringEnumConverter());
        options.MakeReadOnly(populateMissingResolver: true);
        return options;
    }
}

static class ObservationMaterializerTypeCache<T>
{
    public static PropertyInfo[] ReadableProperties { get; } = ShapeTypeInspector.GetReadableProperties<T>();

    public static ConstructorInfo[] PublicConstructors { get; } =
        typeof(T).GetConstructors(BindingFlags.Public | BindingFlags.Instance);

    public static ConstructorInfo? DefaultConstructor { get; } = typeof(T).GetConstructor(Type.EmptyTypes);

    public static MethodInfo ReadMappedValueMethod { get; } =
        typeof(ObservationMaterializerBuilder<T>).GetMethod(
            "ReadMappedValue",
            BindingFlags.Static | BindingFlags.NonPublic)
        ?? throw new InvalidOperationException("Observation materializer read method was not found.");

    public static MethodInfo TryGetFieldByOrdinalMethod { get; } =
        typeof(IOrdinalObservationFieldReader).GetMethod(
            nameof(IOrdinalObservationFieldReader.TryGetField),
            [typeof(int), typeof(ObservationValue).MakeByRefType()])
        ?? throw new InvalidOperationException("Observation ordinal reader method was not found.");

    public static MethodInfo ConvertObservedValueMethod { get; } =
        typeof(ObservationMaterializerBuilder<T>).GetMethod(
            "ConvertObservedValue",
            BindingFlags.Static | BindingFlags.NonPublic)
        ?? throw new InvalidOperationException("Observation materializer conversion method was not found.");

    public static MethodInfo TryGetBytesByOrdinalMethod { get; } =
        typeof(IOrdinalObservationFieldReader).GetMethod(nameof(IOrdinalObservationFieldReader.TryGetBytes))
        ?? throw new InvalidOperationException("Observation ordinal bytes reader method was not found.");

    public static MethodInfo ResolveMissingValueMethod { get; } =
        typeof(ObservationMaterializerBuilder<T>).GetMethod(
            "ResolveMissingValue",
            BindingFlags.Static | BindingFlags.NonPublic)
        ?? throw new InvalidOperationException("Observation materializer missing-value method was not found.");
}

static class DefaultObservationMaterializerCache<T>
{
    static readonly ConcurrentDictionary<QualifiedShapeId, ObservationMaterializer<T>> Materializers = [];

    public static ObservationMaterializer<T> Get(QualifiedShapeId shapeId) =>
        Materializers.GetOrAdd(
            shapeId,
            static currentShapeId => new ObservationMaterializerBuilder<T>(currentShapeId).Compile());
}
