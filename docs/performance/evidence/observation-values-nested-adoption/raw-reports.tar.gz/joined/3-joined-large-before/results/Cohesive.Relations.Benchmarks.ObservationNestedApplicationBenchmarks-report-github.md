```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method           | Workload     | Mean     | Error    | StdDev   | Median   | Op/s  | Gen0     | Gen1     | Allocated |
|----------------- |------------- |---------:|---------:|---------:|---------:|------:|---------:|---------:|----------:|
| IngestAndProject | joined-large | 11.90 ms | 18.40 ms | 6.562 ms | 8.853 ms | 84.07 | 750.0000 | 250.0000 |   6.95 MB |
