```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method           | Workload     | Mean     | Error    | StdDev   | Median   | Op/s  | Gen0     | Gen1     | Allocated |
|----------------- |------------- |---------:|---------:|---------:|---------:|------:|---------:|---------:|----------:|
| IngestAndProject | joined-large | 10.27 ms | 12.38 ms | 4.416 ms | 8.129 ms | 97.39 | 428.5714 | 142.8571 |   4.21 MB |
