```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method           | Workload   | Mean     | Error    | StdDev   | Median   | Op/s    | Gen0    | Gen1   | Allocated |
|----------------- |----------- |---------:|---------:|---------:|---------:|--------:|--------:|-------:|----------:|
| IngestAndProject | joined-128 | 355.1 μs | 781.9 μs | 278.8 μs | 183.3 μs | 2,815.8 | 24.0385 | 4.8077 | 227.96 KB |
