```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method           | Workload     | Mean     | Error     | StdDev    | Op/s  | Gen0     | Gen1    | Gen2    | Allocated |
|----------------- |------------- |---------:|----------:|----------:|------:|---------:|--------:|--------:|----------:|
| IngestAndProject | sparse-large | 1.416 ms | 0.0066 ms | 0.0017 ms | 706.4 | 156.2500 | 93.7500 | 31.2500 |   1.13 MB |
