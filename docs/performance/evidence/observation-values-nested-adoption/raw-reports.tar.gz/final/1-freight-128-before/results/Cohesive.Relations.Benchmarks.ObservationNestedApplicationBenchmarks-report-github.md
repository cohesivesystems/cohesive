```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method           | Workload    | Mean     | Error    | StdDev   | Median   | Op/s    | Gen0   | Allocated |
|----------------- |------------ |---------:|---------:|---------:|---------:|--------:|-------:|----------:|
| IngestAndProject | freight-128 | 146.7 μs | 223.3 μs | 79.62 μs | 108.8 μs | 6,818.9 | 8.9286 |  74.63 KB |
