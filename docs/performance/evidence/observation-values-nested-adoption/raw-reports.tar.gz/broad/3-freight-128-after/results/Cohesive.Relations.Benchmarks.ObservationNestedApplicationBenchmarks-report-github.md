```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method           | Workload    | Mean     | Error    | StdDev   | Op/s     | Gen0   | Allocated |
|----------------- |------------ |---------:|---------:|---------:|---------:|-------:|----------:|
| IngestAndProject | freight-128 | 78.72 μs | 1.821 μs | 0.649 μs | 12,703.2 | 8.0645 |  78.49 KB |
