```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method           | Workload    | Mean     | Error    | StdDev   | Op/s     | Gen0   | Gen1   | Allocated |
|----------------- |------------ |---------:|---------:|---------:|---------:|-------:|-------:|----------:|
| IngestAndProject | freight-128 | 77.68 μs | 2.419 μs | 0.863 μs | 12,872.9 | 8.9286 | 1.1646 |  75.13 KB |
