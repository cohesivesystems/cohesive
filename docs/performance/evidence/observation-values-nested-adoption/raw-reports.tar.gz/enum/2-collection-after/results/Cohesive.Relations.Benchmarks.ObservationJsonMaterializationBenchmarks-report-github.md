```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method            | Workload   | Mean     | Error    | StdDev   | Op/s     | Gen0   | Gen1   | Allocated |
|------------------ |----------- |---------:|---------:|---------:|---------:|-------:|-------:|----------:|
| StrictOrdinalPlan | collection | 30.98 μs | 0.461 μs | 0.165 μs | 32,283.4 | 5.2340 | 0.6158 |   43.5 KB |
