```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method           | Workload         | Mean     | Error    | StdDev   | Op/s     | Gen0    | Gen1   | Allocated |
|----------------- |----------------- |---------:|---------:|---------:|---------:|--------:|-------:|----------:|
| IngestAndProject | freight-case-128 | 86.21 μs | 1.487 μs | 0.530 μs | 11,600.2 | 17.1233 | 2.1404 | 141.08 KB |
