```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method         | Workload   | Mean         | Error        | StdDev     | Op/s      | Gen0      | Gen1      | Gen2     | Allocated  |
|--------------- |----------- |-------------:|-------------:|-----------:|----------:|----------:|----------:|---------:|-----------:|
| **DecodeAndAdmit** | **collection** |  **1,310.58 μs** | **1,014.937 μs** | **530.832 μs** |    **763.02** |   **12.5000** |         **-** |        **-** |  **154.31 KB** |
| **DecodeAndAdmit** | **flat**       |     **56.13 μs** |     **0.535 μs** |   **0.280 μs** | **17,815.85** |    **4.3025** |    **0.2264** |        **-** |   **36.36 KB** |
| **DecodeAndAdmit** | **large**      | **26,939.48 μs** |   **591.095 μs** | **309.154 μs** |     **37.12** | **1000.0000** | **1000.0000** | **444.4444** | **6402.48 KB** |
| **DecodeAndAdmit** | **nested**     |    **105.22 μs** |     **0.636 μs** |   **0.283 μs** |  **9,503.60** |    **5.4167** |    **0.4167** |        **-** |   **44.65 KB** |
