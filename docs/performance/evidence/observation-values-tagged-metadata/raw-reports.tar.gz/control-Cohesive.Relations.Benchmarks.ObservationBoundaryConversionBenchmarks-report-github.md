```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=5  IterationTime=250ms  
WarmupCount=3  

```
| Method         | Workload   | Mean           | Error        | StdDev      | Op/s        | Gen0     | Gen1    | Gen2    | Allocated  |
|--------------- |----------- |---------------:|-------------:|------------:|------------:|---------:|--------:|--------:|-----------:|
| **DecodePortable** | **collection** |    **64,620.1 ns** |    **248.72 ns** |    **38.49 ns** |    **15,475.1** |   **4.6296** |  **0.2572** |       **-** |   **38.53 KB** |
| **DecodePortable** | **flat**       |       **940.6 ns** |      **8.55 ns** |     **1.32 ns** | **1,063,099.7** |   **0.1770** |       **-** |       **-** |    **1.46 KB** |
| **DecodePortable** | **large**      | **2,396,059.5 ns** | **27,982.22 ns** | **4,330.28 ns** |       **417.4** | **142.8571** | **80.3571** | **44.6429** | **1134.07 KB** |
| **DecodePortable** | **nested**     |     **2,720.7 ns** |     **21.25 ns** |     **5.52 ns** |   **367,548.0** |   **0.4900** |       **-** |       **-** |    **4.09 KB** |
