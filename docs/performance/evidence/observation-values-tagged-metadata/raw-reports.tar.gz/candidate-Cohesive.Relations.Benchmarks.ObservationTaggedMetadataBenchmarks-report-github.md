```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=5  IterationTime=250ms  
WarmupCount=3  

```
| Method | Workload     | Mean     | Error    | StdDev   | Op/s         | Allocated |
|------- |------------- |---------:|---------:|---------:|-------------:|----------:|
| **Decode** | **escaped-null** | **68.38 ns** | **0.735 ns** | **0.191 ns** | **14,623,845.9** |         **-** |
| **Decode** | **null**         | **48.94 ns** | **0.661 ns** | **0.172 ns** | **20,432,367.2** |         **-** |
| **Decode** | **undefined**    | **50.64 ns** | **0.744 ns** | **0.193 ns** | **19,746,044.1** |         **-** |
