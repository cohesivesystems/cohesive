```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method         | Workload   | Mean         | Error        | StdDev     | Op/s      | Gen0     | Gen1     | Gen2     | Allocated  |
|--------------- |----------- |-------------:|-------------:|-----------:|----------:|---------:|---------:|---------:|-----------:|
| **DecodeAndAdmit** | **collection** |  **1,450.01 μs** | **1,068.554 μs** | **558.875 μs** |    **689.65** |  **12.5000** |        **-** |        **-** |  **154.31 KB** |
| **DecodeAndAdmit** | **flat**       |     **57.56 μs** |     **1.086 μs** |   **0.568 μs** | **17,374.62** |   **4.4476** |   **0.2341** |        **-** |   **36.36 KB** |
| **DecodeAndAdmit** | **large**      | **26,135.07 μs** |   **696.030 μs** | **364.037 μs** |     **38.26** | **888.8889** | **888.8889** | **333.3333** | **6516.01 KB** |
| **DecodeAndAdmit** | **nested**     |    **103.93 μs** |     **1.391 μs** |   **0.728 μs** |  **9,622.13** |   **5.3105** |   **0.4085** |        **-** |   **44.64 KB** |
