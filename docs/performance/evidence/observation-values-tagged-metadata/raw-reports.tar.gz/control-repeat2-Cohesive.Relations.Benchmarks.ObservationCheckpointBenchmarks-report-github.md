```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=8  IterationTime=250ms  
WarmupCount=6  

```
| Method         | Workload   | Mean         | Error      | StdDev     | Op/s      | Gen0     | Gen1     | Gen2     | Allocated |
|--------------- |----------- |-------------:|-----------:|-----------:|----------:|---------:|---------:|---------:|----------:|
| **DecodeAndAdmit** | **collection** |    **960.91 μs** |  **17.859 μs** |   **6.369 μs** |  **1,040.68** |  **12.5000** |        **-** |        **-** | **154.37 KB** |
| **DecodeAndAdmit** | **flat**       |     **59.19 μs** |   **0.433 μs** |   **0.226 μs** | **16,895.49** |   **4.2939** |   **0.2385** |        **-** |  **36.66 KB** |
| **DecodeAndAdmit** | **large**      | **26,298.02 μs** | **926.270 μs** | **484.457 μs** |     **38.03** | **888.8889** | **888.8889** | **333.3333** | **6045.6 KB** |
| **DecodeAndAdmit** | **nested**     |    **103.73 μs** |   **2.499 μs** |   **1.307 μs** |  **9,640.49** |   **5.3454** |   **0.4112** |        **-** |   **46.2 KB** |
