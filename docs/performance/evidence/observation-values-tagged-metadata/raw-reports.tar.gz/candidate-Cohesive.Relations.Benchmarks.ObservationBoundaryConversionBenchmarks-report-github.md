```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=5  IterationTime=250ms  
WarmupCount=3  

```
| Method         | Workload   | Mean           | Error        | StdDev      | Op/s        | Gen0     | Gen1    | Gen2    | Allocated |
|--------------- |----------- |---------------:|-------------:|------------:|------------:|---------:|--------:|--------:|----------:|
| **DecodePortable** | **collection** |    **63,239.6 ns** |    **912.12 ns** |   **141.15 ns** |    **15,812.9** |   **4.5732** |  **0.2541** |       **-** |  **38.42 KB** |
| **DecodePortable** | **flat**       |       **960.2 ns** |     **10.94 ns** |     **2.84 ns** | **1,041,497.6** |   **0.1537** |       **-** |       **-** |   **1.28 KB** |
| **DecodePortable** | **large**      | **2,367,138.9 ns** | **25,529.59 ns** | **3,950.73 ns** |       **422.5** | **142.8571** | **80.3571** | **44.6429** |   **1135 KB** |
| **DecodePortable** | **nested**     |     **2,729.0 ns** |     **19.96 ns** |     **5.18 ns** |   **366,434.2** |   **0.3934** |       **-** |       **-** |   **3.28 KB** |
