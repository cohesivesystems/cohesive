```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=5  IterationTime=250ms  
WarmupCount=3  

```
| Method         | Workload   | Mean         | Error        | StdDev     | Op/s      | Gen0      | Gen1      | Gen2     | Allocated  |
|--------------- |----------- |-------------:|-------------:|-----------:|----------:|----------:|----------:|---------:|-----------:|
| **DecodeAndAdmit** | **collection** |    **944.98 μs** |   **693.105 μs** | **107.259 μs** |  **1,058.23** |   **17.8571** |         **-** |        **-** |     **169 KB** |
| **DecodeAndAdmit** | **flat**       |     **58.45 μs** |     **2.412 μs** |   **0.373 μs** | **17,108.15** |    **4.4476** |    **0.2341** |        **-** |   **36.36 KB** |
| **DecodeAndAdmit** | **large**      | **26,616.13 μs** | **1,852.700 μs** | **481.140 μs** |     **37.57** | **1111.1111** | **1000.0000** | **444.4444** | **7317.02 KB** |
| **DecodeAndAdmit** | **nested**     |    **103.61 μs** |     **2.007 μs** |   **0.521 μs** |  **9,651.52** |    **5.3105** |    **0.4085** |        **-** |   **44.64 KB** |
