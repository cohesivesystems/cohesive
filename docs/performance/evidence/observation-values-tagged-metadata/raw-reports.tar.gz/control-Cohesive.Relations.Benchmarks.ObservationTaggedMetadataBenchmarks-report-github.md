```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=5  IterationTime=250ms  
WarmupCount=3  

```
| Method | Workload     | Mean     | Error    | StdDev   | Op/s         | Gen0   | Allocated |
|------- |------------- |---------:|---------:|---------:|-------------:|-------:|----------:|
| **Decode** | **escaped-null** | **65.69 ns** | **3.923 ns** | **1.019 ns** | **15,223,535.7** | **0.0037** |      **32 B** |
| **Decode** | **null**         | **55.50 ns** | **0.404 ns** | **0.063 ns** | **18,019,226.3** | **0.0036** |      **32 B** |
| **Decode** | **undefined**    | **60.30 ns** | **2.139 ns** | **0.331 ns** | **16,583,877.5** | **0.0047** |      **40 B** |
