```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method         | Width | WarmupWidth | Mean     | Error   | StdDev  | Op/s        | Gen0   | Allocated |
|--------------- |------ |------------ |---------:|--------:|--------:|------------:|-------:|----------:|
| ParseAndLookup | 4     | 4           | 230.6 ns | 6.77 ns | 2.41 ns | 4,337,034.3 | 0.0443 |     376 B |
