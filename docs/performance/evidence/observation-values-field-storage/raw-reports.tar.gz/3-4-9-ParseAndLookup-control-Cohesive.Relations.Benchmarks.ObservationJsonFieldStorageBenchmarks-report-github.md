```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method         | Width | WarmupWidth | Mean     | Error   | StdDev  | Op/s        | Gen0   | Allocated |
|--------------- |------ |------------ |---------:|--------:|--------:|------------:|-------:|----------:|
| ParseAndLookup | 9     | 4           | 407.9 ns | 2.42 ns | 0.63 ns | 2,451,606.4 | 0.1658 |   1.37 KB |
