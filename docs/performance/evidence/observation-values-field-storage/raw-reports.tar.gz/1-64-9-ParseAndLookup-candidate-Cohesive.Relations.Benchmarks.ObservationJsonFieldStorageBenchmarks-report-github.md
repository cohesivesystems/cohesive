```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method         | Width | WarmupWidth | Mean     | Error   | StdDev  | Op/s        | Gen0   | Allocated |
|--------------- |------ |------------ |---------:|--------:|--------:|------------:|-------:|----------:|
| ParseAndLookup | 9     | 64          | 461.5 ns | 2.56 ns | 0.91 ns | 2,166,694.1 | 0.1241 |   1.03 KB |
