```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method         | Width | WarmupWidth | Mean     | Error     | StdDev    | Op/s      | Gen0   | Gen1   | Allocated |
|--------------- |------ |------------ |---------:|----------:|----------:|----------:|-------:|-------:|----------:|
| ParseAndLookup | 64    | 4           | 3.215 μs | 0.1750 μs | 0.0624 μs | 311,058.2 | 0.9863 | 0.0159 |   8.18 KB |
