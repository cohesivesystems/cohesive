```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method         | Width | WarmupWidth | Mean     | Error     | StdDev    | Op/s      | Gen0   | Allocated |
|--------------- |------ |------------ |---------:|----------:|----------:|----------:|-------:|----------:|
| ParseAndLookup | 32    | 4           | 2.737 μs | 0.1101 μs | 0.0392 μs | 365,346.3 | 0.3854 |    3.2 KB |
