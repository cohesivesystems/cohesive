```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method         | Width | WarmupWidth | Mean     | Error    | StdDev  | Op/s        | Gen0   | Allocated |
|--------------- |------ |------------ |---------:|---------:|--------:|------------:|-------:|----------:|
| ParseAndLookup | 16    | 64          | 907.6 ns | 13.26 ns | 4.73 ns | 1,101,767.9 | 0.1567 |    1.3 KB |
