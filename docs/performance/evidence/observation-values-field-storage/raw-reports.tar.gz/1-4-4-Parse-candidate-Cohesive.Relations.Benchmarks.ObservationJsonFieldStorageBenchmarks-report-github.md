```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method | Width | WarmupWidth | Mean     | Error   | StdDev  | Op/s        | Gen0   | Allocated |
|------- |------ |------------ |---------:|--------:|--------:|------------:|-------:|----------:|
| Parse  | 4     | 4           | 159.9 ns | 1.44 ns | 0.51 ns | 6,255,567.8 | 0.0446 |     376 B |
