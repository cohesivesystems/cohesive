```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method | Count | Route         | Mean     | Error    | StdDev   | Op/s    | Gen0     | Gen1    | Gen2    | Allocated |
|------- |------ |-------------- |---------:|---------:|---------:|--------:|---------:|--------:|--------:|----------:|
| Read   | 4096  | compatibility | 623.1 μs | 157.5 μs | 56.17 μs | 1,604.8 | 116.0714 | 53.5714 | 35.7143 | 961.37 KB |
