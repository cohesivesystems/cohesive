```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method   | Function | Count | Selector | Mean     | Error    | StdDev  | Op/s    | Allocated |
|--------- |--------- |------ |--------- |---------:|---------:|--------:|--------:|----------:|
| Evaluate | sum      | 4096  | True     | 161.9 μs | 10.70 μs | 3.82 μs | 6,177.2 |      80 B |
