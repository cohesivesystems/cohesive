```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method      | Workload | Mean     | Error    | StdDev   | Op/s     | Gen0   | Gen1   | Allocated |
|------------ |--------- |---------:|---------:|---------:|---------:|-------:|-------:|----------:|
| ParseDirect | nested   | 13.88 μs | 0.227 μs | 0.059 μs | 72,049.8 | 1.4029 | 0.0701 |   11.9 KB |
