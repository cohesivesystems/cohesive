```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method      | Workload | Mean     | Error    | StdDev   | Op/s     | Gen0   | Gen1   | Allocated |
|------------ |--------- |---------:|---------:|---------:|---------:|-------:|-------:|----------:|
| ParseDirect | nested   | 13.04 μs | 0.153 μs | 0.054 μs | 76,680.7 | 1.4219 | 0.0646 |   11.9 KB |
