```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method | Workload | Mean     | Error    | StdDev   | Median   | Op/s  | Allocated |
|------- |--------- |---------:|---------:|---------:|---------:|------:|----------:|
| Encode | large    | 11.44 ms | 11.27 ms | 4.018 ms | 9.044 ms | 87.41 |   2.12 MB |
