```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  Categories=Warm,Simple  

```
| Method                   | RowCount | Mean     | Error   | StdDev  | Op/s        | Gen0   | Allocated |
|------------------------- |--------- |---------:|--------:|--------:|------------:|-------:|----------:|
| CompiledKernelOnlySimple | 32       | 734.8 ns | 8.30 ns | 2.96 ns | 1,360,949.2 | 0.2145 |   1.77 KB |
