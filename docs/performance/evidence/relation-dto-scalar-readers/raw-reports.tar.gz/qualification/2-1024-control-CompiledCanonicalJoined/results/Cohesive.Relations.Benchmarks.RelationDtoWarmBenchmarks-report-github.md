```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  Categories=Warm,Joined  

```
| Method                  | RowCount | Mean     | Error   | StdDev  | Op/s    | Gen0    | Gen1   | Allocated |
|------------------------ |--------- |---------:|--------:|--------:|--------:|--------:|-------:|----------:|
| CompiledCanonicalJoined | 1024     | 101.7 μs | 0.74 μs | 0.19 μs | 9,833.9 | 13.7195 | 3.0488 | 112.36 KB |
