```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  Categories=Warm,Simple  

```
| Method                   | RowCount | Mean     | Error   | StdDev  | Op/s        | Gen0   | Allocated |
|------------------------- |--------- |---------:|--------:|--------:|------------:|-------:|----------:|
| CompiledKernelOnlySimple | 32       | 717.3 ns | 8.27 ns | 2.15 ns | 1,394,188.9 | 0.2162 |   1.77 KB |
