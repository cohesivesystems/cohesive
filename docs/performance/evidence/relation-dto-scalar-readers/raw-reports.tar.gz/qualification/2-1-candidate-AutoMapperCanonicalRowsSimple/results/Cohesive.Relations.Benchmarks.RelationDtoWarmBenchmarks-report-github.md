```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  Categories=Warm,Simple  

```
| Method                        | RowCount | Mean     | Error    | StdDev   | Op/s         | Gen0   | Allocated |
|------------------------------ |--------- |---------:|---------:|---------:|-------------:|-------:|----------:|
| AutoMapperCanonicalRowsSimple | 1        | 50.19 ns | 1.584 ns | 0.411 ns | 19,925,206.4 | 0.0093 |      80 B |
