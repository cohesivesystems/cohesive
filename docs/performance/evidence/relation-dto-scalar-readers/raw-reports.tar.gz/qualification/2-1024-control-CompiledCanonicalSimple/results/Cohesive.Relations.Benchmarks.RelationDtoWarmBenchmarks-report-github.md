```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  Categories=Warm,Simple  

```
| Method                  | RowCount | Mean     | Error    | StdDev   | Op/s     | Gen0   | Gen1   | Allocated |
|------------------------ |--------- |---------:|---------:|---------:|---------:|-------:|-------:|----------:|
| CompiledCanonicalSimple | 1024     | 30.38 μs | 0.618 μs | 0.220 μs | 32,918.4 | 7.8313 | 1.2048 |  64.35 KB |
