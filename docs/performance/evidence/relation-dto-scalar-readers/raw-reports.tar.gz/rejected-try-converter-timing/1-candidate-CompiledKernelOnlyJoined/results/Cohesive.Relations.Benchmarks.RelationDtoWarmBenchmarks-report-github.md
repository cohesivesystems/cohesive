```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  Categories=Warm,Joined  

```
| Method                   | RowCount | Mean     | Error   | StdDev  | Op/s    | Gen0    | Gen1   | Allocated |
|------------------------- |--------- |---------:|--------:|--------:|--------:|--------:|-------:|----------:|
| CompiledKernelOnlyJoined | 1024     | 115.2 μs | 0.34 μs | 0.09 μs | 8,683.0 | 12.6147 | 2.8670 | 104.02 KB |
