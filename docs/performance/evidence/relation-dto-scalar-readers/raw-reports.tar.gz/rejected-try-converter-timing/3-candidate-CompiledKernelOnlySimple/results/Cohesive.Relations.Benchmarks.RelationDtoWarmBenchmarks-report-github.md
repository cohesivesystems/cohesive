```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  Categories=Warm,Simple  

```
| Method                   | RowCount | Mean     | Error    | StdDev   | Op/s     | Gen0   | Gen1   | Allocated |
|------------------------- |--------- |---------:|---------:|---------:|---------:|-------:|-------:|----------:|
| CompiledKernelOnlySimple | 1024     | 31.07 μs | 0.322 μs | 0.115 μs | 32,184.2 | 6.8579 | 1.0910 |  56.02 KB |
