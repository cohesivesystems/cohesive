```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  Categories=Warm,Simple  

```
| Method                   | RowCount | Mean     | Error    | StdDev   | Op/s     | Gen0   | Gen1   | Allocated |
|------------------------- |--------- |---------:|---------:|---------:|---------:|-------:|-------:|----------:|
| CompiledKernelOnlySimple | 1024     | 32.30 μs | 2.640 μs | 0.686 μs | 30,957.5 | 6.7525 | 0.9422 |  56.02 KB |
