```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  Categories=Warm,Simple  

```
| Method                        | RowCount | Mean     | Error    | StdDev   | Op/s     | Gen0   | Gen1   | Allocated |
|------------------------------ |--------- |---------:|---------:|---------:|---------:|-------:|-------:|----------:|
| AutoMapperCanonicalRowsSimple | 1024     | 24.28 μs | 0.113 μs | 0.029 μs | 41,190.9 | 6.8226 | 0.9747 |  56.02 KB |
