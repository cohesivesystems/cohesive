```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method      | Width | Count | Scenario     | Mean     | Error     | StdDev    | Op/s  | Gen0     | Gen1    | Allocated |
|------------ |------ |------ |------------- |---------:|----------:|----------:|------:|---------:|--------:|----------:|
| ParseShared | 256   | 128   | sparse-array | 1.140 ms | 0.0670 ms | 0.0239 ms | 876.9 | 156.2500 | 62.5000 |   1.49 MB |
