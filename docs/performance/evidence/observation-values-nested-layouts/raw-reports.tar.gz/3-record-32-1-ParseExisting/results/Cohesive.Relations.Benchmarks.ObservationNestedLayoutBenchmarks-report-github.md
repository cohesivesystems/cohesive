```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method        | Width | Count | Scenario | Mean     | Error     | StdDev    | Op/s      | Gen0   | Gen1   | Allocated |
|-------------- |------ |------ |--------- |---------:|----------:|----------:|----------:|-------:|-------:|----------:|
| ParseExisting | 32    | 1     | record   | 2.371 μs | 0.0186 μs | 0.0048 μs | 421,790.0 | 0.5241 | 0.0119 |   4.29 KB |
