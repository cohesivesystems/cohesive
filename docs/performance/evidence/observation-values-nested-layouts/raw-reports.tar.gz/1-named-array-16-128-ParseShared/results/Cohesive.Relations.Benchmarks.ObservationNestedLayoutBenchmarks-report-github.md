```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method      | Width | Count | Scenario    | Mean     | Error   | StdDev  | Op/s    | Gen0   | Gen1   | Allocated |
|------------ |------ |------ |------------ |---------:|--------:|--------:|--------:|-------:|-------:|----------:|
| ParseShared | 16    | 128   | named-array | 104.7 μs | 2.76 μs | 0.72 μs | 9,548.6 | 9.2975 | 2.5826 |  76.12 KB |
