```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method        | Width | Count | Scenario    | Mean     | Error   | StdDev  | Op/s    | Gen0    | Gen1    | Allocated |
|-------------- |------ |------ |------------ |---------:|--------:|--------:|--------:|--------:|--------:|----------:|
| ParseExisting | 32    | 128   | named-array | 322.5 μs | 3.35 μs | 1.20 μs | 3,100.8 | 65.7051 | 30.4487 | 541.18 KB |
