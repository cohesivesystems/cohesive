```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method      | Width | Count | Scenario        | Mean     | Error   | StdDev  | Op/s    | Gen0   | Gen1   | Allocated |
|------------ |------ |------ |---------------- |---------:|--------:|--------:|--------:|-------:|-------:|----------:|
| ParseShared | 16    | 128   | reordered-array | 111.0 μs | 3.70 μs | 1.32 μs | 9,007.1 | 8.1522 | 2.7174 |  76.14 KB |
