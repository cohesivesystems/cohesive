```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method      | Width | Count | Scenario | Mean     | Error     | StdDev    | Op/s      | Gen0   | Allocated |
|------------ |------ |------ |--------- |---------:|----------:|----------:|----------:|-------:|----------:|
| ParseShared | 16    | 1     | nested   | 1.133 μs | 0.0265 μs | 0.0069 μs | 882,893.1 | 0.1253 |   1.03 KB |
