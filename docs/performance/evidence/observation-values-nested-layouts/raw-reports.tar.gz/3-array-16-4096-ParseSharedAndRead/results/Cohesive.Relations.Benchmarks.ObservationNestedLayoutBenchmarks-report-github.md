```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method             | Width | Count | Scenario | Mean     | Error     | StdDev    | Op/s  | Gen0     | Gen1     | Gen2    | Allocated |
|------------------- |------ |------ |--------- |---------:|----------:|----------:|------:|---------:|---------:|--------:|----------:|
| ParseSharedAndRead | 16    | 4096  | array    | 4.688 ms | 0.0622 ms | 0.0222 ms | 213.3 | 318.1818 | 204.5455 | 90.9091 |    2.4 MB |
