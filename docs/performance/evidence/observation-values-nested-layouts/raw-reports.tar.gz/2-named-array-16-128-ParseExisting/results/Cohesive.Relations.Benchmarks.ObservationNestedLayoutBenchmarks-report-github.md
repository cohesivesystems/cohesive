```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method        | Width | Count | Scenario    | Mean     | Error   | StdDev  | Op/s    | Gen0    | Allocated |
|-------------- |------ |------ |------------ |---------:|--------:|--------:|--------:|--------:|----------:|
| ParseExisting | 16    | 128   | named-array | 141.8 μs | 6.74 μs | 2.40 μs | 7,052.5 | 17.7557 |  146.9 KB |
