```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method      | Width | Count | Scenario | Mean     | Error     | StdDev    | Op/s  | Gen0     | Gen1    | Gen2    | Allocated |
|------------ |------ |------ |--------- |---------:|----------:|----------:|------:|---------:|--------:|--------:|----------:|
| ParseShared | 4     | 4096  | array    | 1.168 ms | 0.0161 ms | 0.0057 ms | 856.2 | 104.1667 | 62.5000 | 41.6667 |    909 KB |
