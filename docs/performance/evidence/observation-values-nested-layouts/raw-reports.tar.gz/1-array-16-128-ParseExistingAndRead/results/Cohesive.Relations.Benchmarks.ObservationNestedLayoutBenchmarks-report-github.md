```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method               | Width | Count | Scenario | Mean     | Error   | StdDev  | Op/s    | Gen0    | Gen1   | Allocated |
|--------------------- |------ |------ |--------- |---------:|--------:|--------:|--------:|--------:|-------:|----------:|
| ParseExistingAndRead | 16    | 128   | array    | 155.8 μs | 9.25 μs | 3.30 μs | 6,418.0 | 16.5663 | 3.7651 | 137.29 KB |
