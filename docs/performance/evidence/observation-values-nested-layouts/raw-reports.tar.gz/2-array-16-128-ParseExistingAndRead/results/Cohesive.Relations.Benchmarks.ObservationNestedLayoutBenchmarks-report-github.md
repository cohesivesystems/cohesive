```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method               | Width | Count | Scenario | Mean     | Error   | StdDev  | Op/s    | Gen0    | Gen1   | Allocated |
|--------------------- |------ |------ |--------- |---------:|--------:|--------:|--------:|--------:|-------:|----------:|
| ParseExistingAndRead | 16    | 128   | array    | 156.2 μs | 1.47 μs | 0.52 μs | 6,400.9 | 17.9688 | 4.6875 |  146.9 KB |
