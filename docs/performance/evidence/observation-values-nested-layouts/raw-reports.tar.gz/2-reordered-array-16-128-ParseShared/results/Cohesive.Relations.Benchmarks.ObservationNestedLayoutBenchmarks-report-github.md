```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method      | Width | Count | Scenario        | Mean     | Error   | StdDev  | Op/s    | Gen0   | Gen1   | Allocated |
|------------ |------ |------ |---------------- |---------:|--------:|--------:|--------:|-------:|-------:|----------:|
| ParseShared | 16    | 128   | reordered-array | 110.4 μs | 0.99 μs | 0.35 μs | 9,060.9 | 9.2391 | 2.7174 |  76.12 KB |
