```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method        | Width | Count | Scenario | Mean     | Error     | StdDev    | Op/s  | Gen0     | Gen1    | Gen2    | Allocated  |
|-------------- |------ |------ |--------- |---------:|----------:|----------:|------:|---------:|--------:|--------:|-----------:|
| ParseExisting | 4     | 4096  | array    | 1.517 ms | 0.1262 ms | 0.0328 ms | 659.1 | 125.0000 | 62.5000 | 31.2500 | 1007.56 KB |
