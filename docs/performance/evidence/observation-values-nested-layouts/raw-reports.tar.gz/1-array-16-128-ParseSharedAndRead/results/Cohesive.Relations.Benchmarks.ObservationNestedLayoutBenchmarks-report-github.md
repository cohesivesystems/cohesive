```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method             | Width | Count | Scenario | Mean     | Error   | StdDev  | Op/s    | Gen0   | Allocated |
|------------------- |------ |------ |--------- |---------:|--------:|--------:|--------:|-------:|----------:|
| ParseSharedAndRead | 16    | 128   | array    | 109.1 μs | 6.38 μs | 2.27 μs | 9,164.6 | 8.5227 |  76.14 KB |
