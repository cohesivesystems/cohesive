```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=10  IterationTime=300ms  
WarmupCount=6  

```
| Method      | Width | Count | Scenario   | Mean     | Error   | StdDev  | Op/s    | Gen0    | Gen1    | Allocated |
|------------ |------ |------ |----------- |---------:|--------:|--------:|--------:|--------:|--------:|----------:|
| ParseShared | 16    | 128   | case-array | 239.8 μs | 0.73 μs | 0.44 μs | 4,169.9 | 33.2278 | 12.6582 | 274.87 KB |
