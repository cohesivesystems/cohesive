```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method      | Width | Count | Scenario | Mean     | Error    | StdDev  | Op/s        | Gen0   | Allocated |
|------------ |------ |------ |--------- |---------:|---------:|--------:|------------:|-------:|----------:|
| ParseShared | 4     | 1     | nested   | 510.3 ns | 17.14 ns | 6.11 ns | 1,959,592.7 | 0.0788 |     672 B |
