```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method               | Width | Count | Scenario | Mean     | Error     | StdDev    | Op/s  | Gen0     | Gen1     | Allocated |
|--------------------- |------ |------ |--------- |---------:|----------:|----------:|------:|---------:|---------:|----------:|
| ParseExistingAndRead | 16    | 4096  | array    | 5.971 ms | 0.4788 ms | 0.1243 ms | 167.5 | 500.0000 | 166.6667 |   4.23 MB |
