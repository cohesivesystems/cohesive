```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method        | Width | Count | Scenario        | Mean     | Error   | StdDev  | Op/s    | Gen0    | Gen1   | Allocated |
|-------------- |------ |------ |---------------- |---------:|--------:|--------:|--------:|--------:|-------:|----------:|
| ParseExisting | 16    | 128   | reordered-array | 135.8 μs | 4.85 μs | 1.26 μs | 7,364.9 | 16.6667 | 4.1667 | 137.36 KB |
