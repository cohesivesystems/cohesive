```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method        | Width | Count | Scenario | Mean     | Error   | StdDev  | Op/s        | Gen0   | Allocated |
|-------------- |------ |------ |--------- |---------:|--------:|--------:|------------:|-------:|----------:|
| ParseExisting | 4     | 1     | nested   | 559.0 ns | 5.35 ns | 1.91 ns | 1,788,896.4 | 0.1151 |     984 B |
