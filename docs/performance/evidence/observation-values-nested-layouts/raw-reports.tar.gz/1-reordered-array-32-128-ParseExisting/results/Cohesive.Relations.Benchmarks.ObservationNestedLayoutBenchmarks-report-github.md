```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method        | Width | Count | Scenario        | Mean     | Error    | StdDev   | Op/s    | Gen0    | Gen1    | Allocated |
|-------------- |------ |------ |---------------- |---------:|---------:|---------:|--------:|--------:|--------:|----------:|
| ParseExisting | 32    | 128   | reordered-array | 407.4 μs | 252.3 μs | 89.99 μs | 2,454.7 | 62.5000 | 26.7857 | 541.32 KB |
