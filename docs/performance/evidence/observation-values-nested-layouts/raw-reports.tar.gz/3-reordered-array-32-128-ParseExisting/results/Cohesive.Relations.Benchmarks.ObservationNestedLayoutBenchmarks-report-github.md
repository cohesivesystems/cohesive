```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method        | Width | Count | Scenario        | Mean     | Error   | StdDev  | Op/s    | Gen0    | Gen1    | Allocated |
|-------------- |------ |------ |---------------- |---------:|--------:|--------:|--------:|--------:|--------:|----------:|
| ParseExisting | 32    | 128   | reordered-array | 353.9 μs | 2.75 μs | 0.71 μs | 2,825.4 | 65.9722 | 31.2500 | 541.18 KB |
