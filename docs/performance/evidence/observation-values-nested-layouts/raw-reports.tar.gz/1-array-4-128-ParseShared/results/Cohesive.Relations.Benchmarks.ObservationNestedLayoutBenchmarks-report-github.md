```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method      | Width | Count | Scenario | Mean     | Error    | StdDev   | Op/s     | Gen0   | Gen1   | Allocated |
|------------ |------ |------ |--------- |---------:|---------:|---------:|---------:|-------:|-------:|----------:|
| ParseShared | 4     | 128   | array    | 31.37 μs | 1.417 μs | 0.505 μs | 31,880.9 | 3.3053 | 0.4507 |  28.12 KB |
