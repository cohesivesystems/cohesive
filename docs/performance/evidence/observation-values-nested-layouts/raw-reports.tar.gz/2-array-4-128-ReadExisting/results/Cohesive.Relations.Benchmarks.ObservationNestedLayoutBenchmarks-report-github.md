```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method       | Width | Count | Scenario | Mean     | Error    | StdDev   | Op/s     | Allocated |
|------------- |------ |------ |--------- |---------:|---------:|---------:|---------:|----------:|
| ReadExisting | 4     | 128   | array    | 10.31 μs | 0.074 μs | 0.026 μs | 97,020.1 |         - |
