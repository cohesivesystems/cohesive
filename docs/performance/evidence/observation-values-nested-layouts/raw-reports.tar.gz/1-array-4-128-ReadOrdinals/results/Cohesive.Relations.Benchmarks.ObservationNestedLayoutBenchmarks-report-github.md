```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method       | Width | Count | Scenario | Mean     | Error     | StdDev    | Op/s      | Allocated |
|------------- |------ |------ |--------- |---------:|----------:|----------:|----------:|----------:|
| ReadOrdinals | 4     | 128   | array    | 2.723 μs | 0.0224 μs | 0.0058 μs | 367,283.2 |         - |
