```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method      | Width | Count | Scenario | Mean     | Error     | StdDev    | Op/s  | Gen0     | Gen1    | Gen2    | Allocated |
|------------ |------ |------ |--------- |---------:|----------:|----------:|------:|---------:|--------:|--------:|----------:|
| ParseShared | 4     | 4096  | array    | 1.181 ms | 0.0103 ms | 0.0027 ms | 846.9 | 104.1667 | 62.5000 | 41.6667 |    909 KB |
