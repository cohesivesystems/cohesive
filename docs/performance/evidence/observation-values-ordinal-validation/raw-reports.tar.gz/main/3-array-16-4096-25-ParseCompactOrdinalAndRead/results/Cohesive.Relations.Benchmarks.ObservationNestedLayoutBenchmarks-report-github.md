```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method                     | Width | Count | Scenario | PresentPercent | Mean     | Error     | StdDev    | Op/s  | Gen0     | Gen1     | Gen2    | Allocated |
|--------------------------- |------ |------ |--------- |--------------- |---------:|----------:|----------:|------:|---------:|---------:|--------:|----------:|
| ParseCompactOrdinalAndRead | 16    | 4096  | array    | 25             | 3.016 ms | 0.0942 ms | 0.0336 ms | 331.6 | 439.3939 | 151.5152 | 45.4545 |   3.31 MB |
