```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method                   | Width | Count | Scenario | PresentPercent | Mean     | Error    | StdDev   | Op/s     | Gen0   | Gen1   | Allocated |
|------------------------- |------ |------ |--------- |--------------- |---------:|---------:|---------:|---------:|-------:|-------:|----------:|
| ParseBoundCompactOrdinal | 16    | 128   | array    | 100            | 92.32 μs | 0.745 μs | 0.266 μs | 10,831.7 | 9.1241 | 2.7372 |  76.12 KB |
