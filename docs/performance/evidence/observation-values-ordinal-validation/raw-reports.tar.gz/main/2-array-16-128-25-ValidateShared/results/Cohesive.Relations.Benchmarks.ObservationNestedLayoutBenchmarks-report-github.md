```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method         | Width | Count | Scenario | PresentPercent | Mean     | Error    | StdDev   | Op/s     | Gen0   | Allocated |
|--------------- |------ |------ |--------- |--------------- |---------:|---------:|---------:|---------:|-------:|----------:|
| ValidateShared | 16    | 128   | array    | 25             | 49.12 μs | 0.282 μs | 0.101 μs | 20,357.2 | 8.5449 |     71 KB |
