```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method                      | Width | Count | Scenario    | PresentPercent | Mean     | Error    | StdDev   | Op/s     | Allocated |
|---------------------------- |------ |------ |------------ |--------------- |---------:|---------:|---------:|---------:|----------:|
| ValidateBoundCompactOrdinal | 32    | 128   | named-array | 25             | 12.93 μs | 0.250 μs | 0.065 μs | 77,365.2 |         - |
