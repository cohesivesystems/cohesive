```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method                          | Width | Count | Scenario | PresentPercent | Mean     | Error    | StdDev   | Op/s     | Gen0   | Gen1   | Allocated |
|-------------------------------- |------ |------ |--------- |--------------- |---------:|---------:|---------:|---------:|-------:|-------:|----------:|
| ParseBoundCompactOrdinalAndRead | 32    | 128   | array    | 25             | 64.45 μs | 0.256 μs | 0.091 μs | 15,515.0 | 5.7990 | 0.6443 |  49.12 KB |
