```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method                     | Width | Count | Scenario | PresentPercent | Mean     | Error    | StdDev  | Op/s    | Gen0    | Allocated |
|--------------------------- |------ |------ |--------- |--------------- |---------:|---------:|--------:|--------:|--------:|----------:|
| ParseCompactOrdinalAndRead | 32    | 128   | array    | 25             | 148.2 μs | 10.52 μs | 3.75 μs | 6,748.7 | 17.8571 | 148.12 KB |
