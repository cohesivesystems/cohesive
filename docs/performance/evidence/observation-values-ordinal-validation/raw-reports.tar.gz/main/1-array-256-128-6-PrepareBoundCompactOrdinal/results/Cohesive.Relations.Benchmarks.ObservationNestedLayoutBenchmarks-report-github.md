```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method                     | Width | Count | Scenario | PresentPercent | Mean     | Error    | StdDev   | Op/s     | Gen0    | Gen1   | Allocated |
|--------------------------- |------ |------ |--------- |--------------- |---------:|---------:|---------:|---------:|--------:|-------:|----------:|
| PrepareBoundCompactOrdinal | 256   | 128   | array    | 6              | 60.77 μs | 1.182 μs | 0.307 μs | 16,454.4 | 21.0337 | 4.8077 | 173.57 KB |
