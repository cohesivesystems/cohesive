# Layout-bound nested observation validation

This experiment follows [compact ordinal storage](observation-values-compact-ordinals.md). It profiles nested admission and tests explicit validation-plan bindings to existing ordinal layouts, without changing the stored representation or making a new validator authoritative.

## Mechanism and semantic boundary

The existing `ObservationValidator` and original graph/type declarations retain authority for field presence, nullability, cardinality, scalar interpretation, named types, arrays, recursion, depth and diagnostics. `ObservationValidationPlan.BindLayouts` makes a private copy of the reachable prepared plan links (including cycles), sharing original immutable declarations and prepared metadata. Published graph plans are never modified or made aware of another caller's binding.

Each bound record requires a complete layout with exact unambiguous names and the original field type references, cardinality, presence and nullability. Bindings store a declaration-index-to-ordinal permutation. The internal root admission entry checks the exact original graph and field types; the private projected child graph is physical metadata rather than a replacement domain identity.

The validator recognizes only framework-owned immutable dense or compact storage whose layout object is exactly the bound object. That evidence proves all present keys belong to the complete declared layout, so unknown-member discovery can be skipped. Each declared field is then read by its prebound ordinal, through the same original field/type validation operations. Other storage and layout instances keep the original name-based lookup. Union discriminator exceptions disable this shortcut. Required fields are still checked in declaration order; this experiment intentionally does not add required-field bitmaps or present-only traversal.

On failure, root admission reruns the original unbound detailed interpreter. Nested case variants, unknown members, unsupported typed restoration and malformed JSON retain the benchmark parser's existing whole-input fallback. Strict root duplicate rejection and nested exact decoded last-value-wins behavior remain unchanged. There is no public API, external dependency, new physical storage format, global binding registry or automatic production selection.

Binding inputs are borrowed only during preparation. Bound permutations and child links are privately owned and published only after their closure is complete. Values retain their existing immutable storage; they do not acquire a reference to the private validation closure. Preparation is per parser, while warm validation is per admitted tree/row.

## Profiling evidence

Before the change, sparse nested validation attempts an exact name lookup for every declaration. The first absent optional name creates a per-record case-insensitive dictionary of the present fields. Unknown-member discovery and field validation both traverse the declared fields.

Three initial eight-second warmed profiles cover compact validation at width 16/quarter-full and width 256/16-present, plus complete packed ingestion at width 16. Four final profiles cover matched reference/bound validation at width 16, bound validation at width 256, and bound ingestion. EventPipe sample stacks and matching JIT disassembly are retained.

The initial width-16 validation profile has 5,874 selected samples; dictionary lookup and case-insensitive hashing account for 1,228 leaf samples (20.9%). At width 256 they account for 1,652 of 5,920 (27.9%). Much of the remaining nested body is inlined into `TryValidateFieldValue`, so sampling cannot assign every operation precisely. In the final matched width-16 profiles, these dictionary/hash leaf samples fall from 1,060 of 5,864 to zero of 5,967 for the bound route. The bound wide profile also has zero such leaf samples.

Sampling percentages are not CPU-cycle attribution. The parse captures contain many runtime suspension/GC-poll frames, and even allocation-free validation has poll frames; these must not be counted as managed allocation cost or evidence of application lock contention. Warm BenchmarkDotNet timing and allocation measurements below are the performance evidence.

## Measurement

Every exact benchmark runs in a fresh process, with four warmups and six 200 ms measurement iterations, repeated three times with counterbalanced route order. Tables report medians of process means; min/max process means and raw BDN statistics are retained. All main comparisons share one frozen dependency closure. A separate matched harness compares the previous and final Core with only `Cohesive.dll` changed.

Validation-only pairs read the exact same retained tree, root value slots and presence bitmap, excluding parsing and metadata preparation. End-to-end pairs parse identical input into the same physical strategy and include complete authoritative root/nested admission. Combined cases add the same prebound field reads. Retained diagnostics run separately before timing and exclude preparation and retention arrays. Layout/plan preparation benchmarks create fresh parsers and layouts over already warmed governing-graph metadata; their results are not cold-process or first-JIT costs.

Fixtures include a single record, a four-wrapper nested chain, inline and named-record arrays, sparse and dense records, and 4,096-row arrays. Width 256 at the 6% setting contains 16 fields (6.25%). All timing fixtures use Int64 fields; semantic tests cover failures and fallback separately.

