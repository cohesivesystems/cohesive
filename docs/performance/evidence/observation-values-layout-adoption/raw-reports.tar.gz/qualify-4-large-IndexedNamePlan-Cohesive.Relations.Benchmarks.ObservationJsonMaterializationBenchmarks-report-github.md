```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=10  IterationTime=300ms  
WarmupCount=6  

```
| Method          | Workload | Mean     | Error     | StdDev    | Op/s  | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated | Alloc Ratio |
|---------------- |--------- |---------:|----------:|----------:|------:|------:|--------:|---------:|--------:|--------:|----------:|------------:|
| IndexedNamePlan | large    | 1.250 ms | 0.0429 ms | 0.0283 ms | 799.9 |  1.00 |    0.03 | 125.0000 | 62.5000 | 31.2500 | 995.92 KB |        1.00 |
