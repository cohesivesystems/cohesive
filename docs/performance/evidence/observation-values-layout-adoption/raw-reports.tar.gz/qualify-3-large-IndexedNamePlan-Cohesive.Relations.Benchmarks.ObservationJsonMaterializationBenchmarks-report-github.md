```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=10  IterationTime=300ms  
WarmupCount=6  

```
| Method          | Workload | Mean     | Error     | StdDev    | Op/s  | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated | Alloc Ratio |
|---------------- |--------- |---------:|----------:|----------:|------:|------:|--------:|---------:|--------:|--------:|----------:|------------:|
| IndexedNamePlan | large    | 1.224 ms | 0.0281 ms | 0.0186 ms | 817.0 |  1.00 |    0.02 | 125.0000 | 62.5000 | 31.2500 | 995.89 KB |        1.00 |
