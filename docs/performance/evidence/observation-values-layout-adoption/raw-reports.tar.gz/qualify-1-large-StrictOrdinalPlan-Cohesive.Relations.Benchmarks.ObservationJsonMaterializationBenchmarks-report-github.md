```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=10  IterationTime=300ms  
WarmupCount=6  

```
| Method            | Workload | Mean     | Error     | StdDev    | Op/s  | Gen0     | Gen1    | Gen2    | Allocated |
|------------------ |--------- |---------:|----------:|----------:|------:|---------:|--------:|--------:|----------:|
| StrictOrdinalPlan | large    | 1.256 ms | 0.0465 ms | 0.0277 ms | 796.4 | 133.9286 | 75.8929 | 35.7143 | 995.85 KB |
