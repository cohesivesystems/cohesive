```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method          | Workload   | Mean     | Error    | StdDev   | Op/s     | Ratio | RatioSD | Gen0   | Gen1   | Allocated | Alloc Ratio |
|---------------- |----------- |---------:|---------:|---------:|---------:|------:|--------:|-------:|-------:|----------:|------------:|
| IndexedNamePlan | collection | 32.12 μs | 1.489 μs | 0.531 μs | 31,137.7 |  1.00 |    0.02 | 5.3934 | 0.6345 |  44.42 KB |        1.00 |
