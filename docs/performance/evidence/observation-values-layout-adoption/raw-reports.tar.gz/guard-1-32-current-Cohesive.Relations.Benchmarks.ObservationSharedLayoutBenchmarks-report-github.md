```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method              | Width | Reads | Mean     | Error     | StdDev    | Op/s      | Gen0   | Allocated |
|-------------------- |------ |------ |---------:|----------:|----------:|----------:|-------:|----------:|
| ParseIndexedAndRead | 32    | 16    | 1.400 μs | 0.0192 μs | 0.0069 μs | 714,307.0 | 0.1281 |   1.09 KB |
