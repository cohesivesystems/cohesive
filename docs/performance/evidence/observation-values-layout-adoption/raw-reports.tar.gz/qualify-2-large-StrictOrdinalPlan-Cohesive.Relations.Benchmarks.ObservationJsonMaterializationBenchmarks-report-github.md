```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=10  IterationTime=300ms  
WarmupCount=6  

```
| Method            | Workload | Mean     | Error     | StdDev    | Op/s  | Gen0     | Gen1    | Gen2    | Allocated |
|------------------ |--------- |---------:|----------:|----------:|------:|---------:|--------:|--------:|----------:|
| StrictOrdinalPlan | large    | 1.245 ms | 0.0291 ms | 0.0173 ms | 803.2 | 125.0000 | 62.5000 | 31.2500 | 995.82 KB |
