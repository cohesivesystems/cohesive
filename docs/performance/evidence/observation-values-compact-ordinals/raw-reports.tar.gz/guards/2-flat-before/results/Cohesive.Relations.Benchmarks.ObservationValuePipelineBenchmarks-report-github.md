```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method      | Workload | Mean     | Error    | StdDev  | Op/s        | Gen0   | Allocated |
|------------ |--------- |---------:|---------:|--------:|------------:|-------:|----------:|
| ParseDirect | flat     | 550.7 ns | 29.88 ns | 7.76 ns | 1,815,753.5 | 0.2007 |   1.64 KB |
