```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method      | Workload   | Mean     | Error    | StdDev   | Op/s     | Gen0   | Gen1   | Allocated |
|------------ |----------- |---------:|---------:|---------:|---------:|-------:|-------:|----------:|
| ParseDirect | collection | 32.75 μs | 0.478 μs | 0.170 μs | 30,536.5 | 4.0796 | 0.4896 |  34.17 KB |
