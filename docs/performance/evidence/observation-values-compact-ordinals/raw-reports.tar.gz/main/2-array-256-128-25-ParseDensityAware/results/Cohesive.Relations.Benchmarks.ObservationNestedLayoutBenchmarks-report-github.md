```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method            | Width | Count | Scenario | PresentPercent | Mean     | Error     | StdDev    | Op/s  | Gen0     | Gen1    | Allocated |
|------------------ |------ |------ |--------- |--------------- |---------:|----------:|----------:|------:|---------:|--------:|----------:|
| ParseDensityAware | 256   | 128   | array    | 25             | 1.060 ms | 0.0057 ms | 0.0015 ms | 943.1 | 114.5833 | 57.2917 |  973.2 KB |
