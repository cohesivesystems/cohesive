```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method              | Width | Count | Scenario    | PresentPercent | Mean     | Error    | StdDev   | Median   | Op/s    | Gen0    | Gen1   | Allocated |
|-------------------- |------ |------ |------------ |--------------- |---------:|---------:|---------:|---------:|--------:|--------:|-------:|----------:|
| ParseCompactOrdinal | 32    | 128   | named-array | 25             | 219.9 μs | 298.0 μs | 106.3 μs | 166.2 μs | 4,547.3 | 17.8571 | 4.4643 | 148.15 KB |
