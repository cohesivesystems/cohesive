```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method            | Width | Count | Scenario | PresentPercent | Mean     | Error    | StdDev   | Op/s     | Gen0   | Allocated |
|------------------ |------ |------ |--------- |--------------- |---------:|---------:|---------:|---------:|-------:|----------:|
| ParseDensityAware | 16    | 128   | array    | 25             | 82.95 μs | 0.870 μs | 0.310 μs | 12,055.2 | 9.3750 |  97.14 KB |
