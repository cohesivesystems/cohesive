```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method                      | Width | Count | Scenario | PresentPercent | Mean     | Error     | StdDev    | Op/s  | Gen0     | Gen1     | Gen2     | Allocated |
|---------------------------- |------ |------ |--------- |--------------- |---------:|----------:|----------:|------:|---------:|---------:|---------:|----------:|
| ParseSharedSeparatedAndRead | 16    | 4096  | array    | 25             | 3.519 ms | 0.0458 ms | 0.0119 ms | 284.2 | 645.8333 | 312.5000 | 145.8333 |   4.63 MB |
