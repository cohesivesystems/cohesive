```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method              | Width | Count | Scenario    | PresentPercent | Mean     | Error   | StdDev  | Op/s    | Gen0    | Gen1   | Allocated |
|-------------------- |------ |------ |------------ |--------------- |---------:|--------:|--------:|--------:|--------:|-------:|----------:|
| ParseCompactOrdinal | 32    | 128   | mixed-array | 100            | 180.1 μs | 6.11 μs | 1.59 μs | 5,553.5 | 14.4231 | 4.8077 | 144.15 KB |
