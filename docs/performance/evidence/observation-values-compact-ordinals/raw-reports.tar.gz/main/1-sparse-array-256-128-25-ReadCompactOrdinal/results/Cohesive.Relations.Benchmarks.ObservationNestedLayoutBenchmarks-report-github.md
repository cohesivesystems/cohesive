```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method             | Width | Count | Scenario     | PresentPercent | Mean     | Error     | StdDev    | Op/s      | Allocated |
|------------------- |------ |------ |------------- |--------------- |---------:|----------:|----------:|----------:|----------:|
| ReadCompactOrdinal | 256   | 128   | sparse-array | 25             | 4.631 μs | 0.0450 μs | 0.0161 μs | 215,946.5 |         - |
