```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method               | Width | Count | Scenario    | PresentPercent | Mean     | Error    | StdDev   | Op/s    | Gen0    | Allocated |
|--------------------- |------ |------ |------------ |--------------- |---------:|---------:|---------:|--------:|--------:|----------:|
| ParseSharedSeparated | 32    | 128   | mixed-array | 100            | 212.1 μs | 113.4 μs | 40.45 μs | 4,715.3 | 22.3214 | 188.65 KB |
