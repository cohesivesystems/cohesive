```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method              | Width | Count | Scenario | PresentPercent | Mean     | Error    | StdDev  | Op/s        | Gen0   | Allocated |
|-------------------- |------ |------ |--------- |--------------- |---------:|---------:|--------:|------------:|-------:|----------:|
| ParseCompactOrdinal | 16    | 1     | nested   | 25             | 885.9 ns | 10.00 ns | 3.56 ns | 1,128,735.0 | 0.1542 |   1.27 KB |
