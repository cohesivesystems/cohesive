```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method        | Width | Count | Scenario | PresentPercent | Mean     | Error    | StdDev   | Op/s    | Gen0    | Allocated |
|-------------- |------ |------ |--------- |--------------- |---------:|---------:|---------:|--------:|--------:|----------:|
| ParseExisting | 256   | 128   | array    | 6              | 953.9 μs | 970.8 μs | 346.2 μs | 1,048.3 | 20.8333 | 274.68 KB |
