```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method              | Width | Count | Scenario | PresentPercent | Mean     | Error   | StdDev  | Op/s    | Gen0   | Gen1   | Allocated |
|-------------------- |------ |------ |--------- |--------------- |---------:|--------:|--------:|--------:|-------:|-------:|----------:|
| ParseCompactOrdinal | 16    | 128   | array    | 100            | 119.2 μs | 2.25 μs | 0.80 μs | 8,390.5 | 8.8443 | 2.3585 |  76.12 KB |
