```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method              | Width | Count | Scenario | PresentPercent | Mean     | Error     | StdDev    | Op/s  | Gen0    | Gen1    | Allocated |
|-------------------- |------ |------ |--------- |--------------- |---------:|----------:|----------:|------:|--------:|--------:|----------:|
| ParseCompactOrdinal | 256   | 128   | array    | 25             | 1.136 ms | 0.0045 ms | 0.0016 ms | 880.5 | 90.9091 | 39.7727 | 773.21 KB |
