```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method            | Width | Count | Scenario    | PresentPercent | Mean     | Error   | StdDev  | Op/s    | Gen0    | Gen1   | Allocated |
|------------------ |------ |------ |------------ |--------------- |---------:|--------:|--------:|--------:|--------:|-------:|----------:|
| ParseDensityAware | 32    | 128   | mixed-array | 100            | 208.9 μs | 1.11 μs | 0.29 μs | 4,786.8 | 16.6667 | 5.2083 | 141.63 KB |
