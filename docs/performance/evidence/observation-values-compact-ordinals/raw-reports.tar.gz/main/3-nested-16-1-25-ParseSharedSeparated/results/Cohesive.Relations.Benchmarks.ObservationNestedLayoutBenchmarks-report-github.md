```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method               | Width | Count | Scenario | PresentPercent | Mean     | Error    | StdDev  | Op/s        | Gen0   | Allocated |
|--------------------- |------ |------ |--------- |--------------- |---------:|---------:|--------:|------------:|-------:|----------:|
| ParseSharedSeparated | 16    | 1     | nested   | 25             | 922.3 ns | 14.67 ns | 3.81 ns | 1,084,236.1 | 0.1932 |   1.59 KB |
