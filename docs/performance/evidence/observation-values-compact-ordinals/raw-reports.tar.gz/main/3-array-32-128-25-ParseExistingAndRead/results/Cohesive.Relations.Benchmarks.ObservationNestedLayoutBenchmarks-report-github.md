```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method               | Width | Count | Scenario | PresentPercent | Mean     | Error   | StdDev  | Op/s    | Gen0    | Gen1   | Allocated |
|--------------------- |------ |------ |--------- |--------------- |---------:|--------:|--------:|--------:|--------:|-------:|----------:|
| ParseExistingAndRead | 32    | 128   | array    | 25             | 163.7 μs | 1.44 μs | 0.51 μs | 6,107.4 | 17.8571 | 2.4351 | 145.98 KB |
