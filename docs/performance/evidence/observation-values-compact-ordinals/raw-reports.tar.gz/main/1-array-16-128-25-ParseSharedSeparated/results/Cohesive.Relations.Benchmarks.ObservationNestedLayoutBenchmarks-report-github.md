```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method               | Width | Count | Scenario | PresentPercent | Mean     | Error    | StdDev   | Op/s     | Gen0    | Gen1   | Allocated |
|--------------------- |------ |------ |--------- |--------------- |---------:|---------:|---------:|---------:|--------:|-------:|----------:|
| ParseSharedSeparated | 16    | 128   | array    | 25             | 69.76 μs | 0.546 μs | 0.195 μs | 14,335.4 | 17.9558 | 5.5249 | 147.12 KB |
