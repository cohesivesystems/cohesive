```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method        | Width | Count | Scenario | PresentPercent | Mean     | Error     | StdDev    | Op/s  | Gen0     | Gen1     | Allocated |
|-------------- |------ |------ |--------- |--------------- |---------:|----------:|----------:|------:|---------:|---------:|----------:|
| ParseExisting | 256   | 128   | array    | 25             | 1.577 ms | 0.2373 ms | 0.0846 ms | 633.9 | 208.3333 | 104.1667 |   1.73 MB |
