```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method        | Width | Count | Scenario | PresentPercent | Mean     | Error     | StdDev    | Op/s  | Gen0     | Gen1     | Allocated |
|-------------- |------ |------ |--------- |--------------- |---------:|----------:|----------:|------:|---------:|---------:|----------:|
| ParseExisting | 16    | 4096  | array    | 25             | 2.601 ms | 0.0342 ms | 0.0122 ms | 384.5 | 300.0000 | 100.0000 |   3.06 MB |
