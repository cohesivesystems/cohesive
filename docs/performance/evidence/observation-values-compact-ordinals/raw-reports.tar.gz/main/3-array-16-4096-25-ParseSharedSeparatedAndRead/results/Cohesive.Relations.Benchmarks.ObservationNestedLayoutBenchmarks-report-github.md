```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method                      | Width | Count | Scenario | PresentPercent | Mean     | Error     | StdDev    | Op/s  | Gen0     | Gen1     | Gen2     | Allocated |
|---------------------------- |------ |------ |--------- |--------------- |---------:|----------:|----------:|------:|---------:|---------:|---------:|----------:|
| ParseSharedSeparatedAndRead | 16    | 4096  | array    | 25             | 3.597 ms | 0.1131 ms | 0.0403 ms | 278.0 | 640.6250 | 312.5000 | 156.2500 |   4.63 MB |
