```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method        | Width | Count | Scenario | PresentPercent | Mean     | Error    | StdDev   | Op/s     | Gen0    | Allocated |
|-------------- |------ |------ |--------- |--------------- |---------:|---------:|---------:|---------:|--------:|----------:|
| ParseExisting | 16    | 128   | array    | 25             | 80.35 μs | 1.427 μs | 0.509 μs | 12,444.9 | 11.9048 |  99.86 KB |
