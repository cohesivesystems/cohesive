```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method                     | Width | Count | Scenario | PresentPercent | Mean     | Error   | StdDev  | Op/s    | Gen0    | Allocated |
|--------------------------- |------ |------ |--------- |--------------- |---------:|--------:|--------:|--------:|--------:|----------:|
| ParseCompactOrdinalAndRead | 32    | 128   | array    | 25             | 144.4 μs | 5.25 μs | 1.87 μs | 6,924.9 | 16.6667 | 148.15 KB |
