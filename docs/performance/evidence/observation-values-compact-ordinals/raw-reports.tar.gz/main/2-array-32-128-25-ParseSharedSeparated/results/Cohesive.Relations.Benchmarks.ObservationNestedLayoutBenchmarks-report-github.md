```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method               | Width | Count | Scenario | PresentPercent | Mean     | Error    | StdDev  | Op/s    | Gen0    | Gen1    | Allocated |
|--------------------- |------ |------ |--------- |--------------- |---------:|---------:|--------:|--------:|--------:|--------:|----------:|
| ParseSharedSeparated | 32    | 128   | array    | 25             | 150.0 μs | 10.64 μs | 3.79 μs | 6,667.6 | 27.3438 | 11.7188 | 237.15 KB |
