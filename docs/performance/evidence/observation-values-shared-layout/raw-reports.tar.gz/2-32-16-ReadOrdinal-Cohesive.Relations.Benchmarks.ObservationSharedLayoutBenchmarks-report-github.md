```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method      | Width | Reads | Mean     | Error    | StdDev   | Op/s         | Allocated |
|------------ |------ |------ |---------:|---------:|---------:|-------------:|----------:|
| ReadOrdinal | 32    | 16    | 17.51 ns | 0.067 ns | 0.017 ns | 57,109,446.2 |         - |
