```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method             | Width | Reads | Mean     | Error     | StdDev    | Op/s      | Gen0   | Allocated |
|------------------- |------ |------ |---------:|----------:|----------:|----------:|-------:|----------:|
| ParseSharedAndRead | 32    | 64    | 1.455 μs | 0.0345 μs | 0.0090 μs | 687,259.1 | 0.1231 |   1.06 KB |
