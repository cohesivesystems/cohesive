```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method              | Width | Reads | Mean     | Error     | StdDev    | Op/s      | Gen0   | Allocated |
|-------------------- |------ |------ |---------:|----------:|----------:|----------:|-------:|----------:|
| ParseIndexedAndRead | 32    | 16    | 1.374 μs | 0.0108 μs | 0.0039 μs | 727,922.4 | 0.1309 |   1.09 KB |
