```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method | Width | WarmupWidth | Mean     | Error    | StdDev   | Op/s         | Gen0   | Allocated |
|------- |------ |------------ |---------:|---------:|---------:|-------------:|-------:|----------:|
| Parse  | 1     | 32          | 56.98 ns | 0.398 ns | 0.142 ns | 17,550,551.9 | 0.0160 |     136 B |
