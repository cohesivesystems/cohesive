```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method | Width | WarmupWidth | Mean     | Error    | StdDev   | Op/s        | Gen0   | Allocated |
|------- |------ |------------ |---------:|---------:|---------:|------------:|-------:|----------:|
| Parse  | 16    | 32          | 560.3 ns | 31.40 ns | 11.20 ns | 1,784,792.9 | 0.1996 |   1.64 KB |
