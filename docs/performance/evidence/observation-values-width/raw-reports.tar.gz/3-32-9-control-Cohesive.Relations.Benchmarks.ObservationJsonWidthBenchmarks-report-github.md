```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method | Width | WarmupWidth | Mean     | Error    | StdDev  | Op/s        | Gen0   | Allocated |
|------- |------ |------------ |---------:|---------:|--------:|------------:|-------:|----------:|
| Parse  | 9     | 32          | 356.9 ns | 33.70 ns | 8.75 ns | 2,801,667.5 | 0.1672 |   1.37 KB |
