```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method | Width | WarmupWidth | Mean     | Error    | StdDev   | Op/s         | Gen0   | Allocated |
|------- |------ |------------ |---------:|---------:|---------:|-------------:|-------:|----------:|
| Parse  | 1     | 32          | 57.27 ns | 1.490 ns | 0.387 ns | 17,462,098.8 | 0.0161 |     136 B |
