```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method | Width | WarmupWidth | Mean     | Error     | StdDev    | Op/s      | Gen0   | Gen1   | Allocated |
|------- |------ |------------ |---------:|----------:|----------:|----------:|-------:|-------:|----------:|
| Parse  | 32    | 4           | 1.296 μs | 0.1308 μs | 0.0466 μs | 771,706.6 | 0.5086 | 0.0065 |    4.2 KB |
