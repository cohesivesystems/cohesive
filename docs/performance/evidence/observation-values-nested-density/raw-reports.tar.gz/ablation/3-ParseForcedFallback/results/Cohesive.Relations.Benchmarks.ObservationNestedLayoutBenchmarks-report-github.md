```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=10  IterationTime=300ms  
WarmupCount=6  

```
| Method              | Width | Count | Scenario   | Mean     | Error   | StdDev  | Op/s    | Gen0    | Gen1    | Allocated |
|-------------------- |------ |------ |----------- |---------:|--------:|--------:|--------:|--------:|--------:|----------:|
| ParseForcedFallback | 16    | 128   | case-array | 202.7 μs | 3.53 μs | 2.34 μs | 4,933.4 | 34.5745 | 14.6277 |  283.9 KB |
