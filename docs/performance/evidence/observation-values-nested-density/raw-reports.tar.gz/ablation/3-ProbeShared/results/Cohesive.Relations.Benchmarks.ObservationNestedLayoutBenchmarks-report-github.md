```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=10  IterationTime=300ms  
WarmupCount=6  

```
| Method      | Width | Count | Scenario   | Mean     | Error   | StdDev  | Op/s        | Gen0   | Allocated |
|------------ |------ |------ |----------- |---------:|--------:|--------:|------------:|-------:|----------:|
| ProbeShared | 16    | 128   | case-array | 131.2 ns | 0.75 ns | 0.50 ns | 7,622,511.5 | 0.0705 |     592 B |
