```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method               | Width | Count | Scenario | PresentPercent | Mean     | Error     | StdDev    | Op/s  | Gen0     | Gen1    | Allocated |
|--------------------- |------ |------ |--------- |--------------- |---------:|----------:|----------:|------:|---------:|--------:|----------:|
| ParseSharedSeparated | 256   | 128   | array    | 50             | 1.512 ms | 0.2019 ms | 0.0720 ms | 661.4 | 218.7500 | 93.7500 |   1.87 MB |
