```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=10  IterationTime=300ms  
WarmupCount=6  

```
| Method            | Width | Count | Scenario   | PresentPercent | Mean     | Error   | StdDev  | Op/s    | Gen0    | Gen1    | Allocated |
|------------------ |------ |------ |----------- |--------------- |---------:|--------:|--------:|--------:|--------:|--------:|----------:|
| ParseDensityAware | 16    | 128   | case-array | 100            | 206.4 μs | 0.39 μs | 0.20 μs | 4,845.8 | 32.9670 | 13.0495 | 274.33 KB |
