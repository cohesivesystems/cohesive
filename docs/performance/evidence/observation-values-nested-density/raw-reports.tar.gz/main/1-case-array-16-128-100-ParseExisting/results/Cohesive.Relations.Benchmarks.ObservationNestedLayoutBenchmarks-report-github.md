```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=10  IterationTime=300ms  
WarmupCount=6  

```
| Method        | Width | Count | Scenario   | PresentPercent | Mean     | Error   | StdDev  | Op/s    | Gen0    | Gen1    | Allocated |
|-------------- |------ |------ |----------- |--------------- |---------:|--------:|--------:|--------:|--------:|--------:|----------:|
| ParseExisting | 16    | 128   | case-array | 100            | 201.4 μs | 0.53 μs | 0.31 μs | 4,965.1 | 33.2447 | 12.6330 | 274.27 KB |
