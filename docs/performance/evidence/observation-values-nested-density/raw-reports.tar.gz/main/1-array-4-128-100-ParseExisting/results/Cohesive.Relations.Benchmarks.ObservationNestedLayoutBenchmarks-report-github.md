```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method        | Width | Count | Scenario | PresentPercent | Mean     | Error    | StdDev   | Op/s     | Gen0   | Gen1   | Allocated |
|-------------- |------ |------ |--------- |--------------- |---------:|---------:|---------:|---------:|-------:|-------:|----------:|
| ParseExisting | 4     | 128   | array    | 100            | 33.75 μs | 0.274 μs | 0.098 μs | 29,629.6 | 4.0323 | 0.6720 |   33.8 KB |
