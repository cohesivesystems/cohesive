```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Unknown processor
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=10  IterationTime=300ms  
WarmupCount=6  

```
| Method               | Width | Count | Scenario   | PresentPercent | Mean     | Error    | StdDev  | Op/s    | Gen0    | Gen1    | Allocated |
|--------------------- |------ |------ |----------- |--------------- |---------:|---------:|--------:|--------:|--------:|--------:|----------:|
| ParseSharedSeparated | 16    | 128   | case-array | 100            | 436.6 μs | 12.66 μs | 7.54 μs | 2,290.5 | 35.5114 | 14.2045 |  294.1 KB |
