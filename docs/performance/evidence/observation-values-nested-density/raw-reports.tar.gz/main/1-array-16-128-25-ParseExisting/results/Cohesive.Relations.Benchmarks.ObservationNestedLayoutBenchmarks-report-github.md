```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method        | Width | Count | Scenario | PresentPercent | Mean     | Error    | StdDev   | Op/s     | Gen0    | Gen1   | Allocated |
|-------------- |------ |------ |--------- |--------------- |---------:|---------:|---------:|---------:|--------:|-------:|----------:|
| ParseExisting | 16    | 128   | array    | 25             | 66.79 μs | 0.639 μs | 0.228 μs | 14,971.5 | 11.9681 | 1.9947 |   99.8 KB |
