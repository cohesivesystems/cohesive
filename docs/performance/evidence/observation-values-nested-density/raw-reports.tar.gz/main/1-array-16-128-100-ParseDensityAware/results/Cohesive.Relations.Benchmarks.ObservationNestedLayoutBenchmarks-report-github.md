```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method            | Width | Count | Scenario | PresentPercent | Mean     | Error   | StdDev  | Op/s    | Gen0   | Gen1   | Allocated |
|------------------ |------ |------ |--------- |--------------- |---------:|--------:|--------:|--------:|-------:|-------:|----------:|
| ParseDensityAware | 16    | 128   | array    | 100            | 112.3 μs | 1.92 μs | 0.69 μs | 8,903.2 | 8.9286 | 2.7902 |  76.12 KB |
