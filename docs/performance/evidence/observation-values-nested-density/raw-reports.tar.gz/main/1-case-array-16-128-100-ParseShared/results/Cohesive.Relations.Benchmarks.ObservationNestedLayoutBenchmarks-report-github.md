```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=10  IterationTime=300ms  
WarmupCount=6  

```
| Method      | Width | Count | Scenario   | PresentPercent | Mean     | Error   | StdDev  | Op/s    | Gen0    | Gen1    | Allocated |
|------------ |------ |------ |----------- |--------------- |---------:|--------:|--------:|--------:|--------:|--------:|----------:|
| ParseShared | 16    | 128   | case-array | 100            | 240.6 μs | 0.57 μs | 0.34 μs | 4,156.1 | 34.4551 | 14.4231 | 284.46 KB |
