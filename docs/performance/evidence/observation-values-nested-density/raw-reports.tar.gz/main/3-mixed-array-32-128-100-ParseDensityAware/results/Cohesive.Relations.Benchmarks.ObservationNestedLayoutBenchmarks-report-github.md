```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method            | Width | Count | Scenario    | PresentPercent | Mean     | Error   | StdDev  | Op/s    | Gen0    | Gen1   | Allocated |
|------------------ |------ |------ |------------ |--------------- |---------:|--------:|--------:|--------:|--------:|-------:|----------:|
| ParseDensityAware | 32    | 128   | mixed-array | 100            | 198.0 μs | 5.71 μs | 1.48 μs | 5,051.4 | 16.6016 | 4.8828 | 141.62 KB |
