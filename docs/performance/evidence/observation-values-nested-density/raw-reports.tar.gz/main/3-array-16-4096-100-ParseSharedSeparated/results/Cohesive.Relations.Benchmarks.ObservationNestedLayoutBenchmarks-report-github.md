```

BenchmarkDotNet v0.15.8, macOS 27.0.1 (26A434) [Darwin 27.0.0]
Apple M5 Max, 1 CPU, 18 logical and 18 physical cores
.NET SDK 10.0.402
  [Host] : .NET 10.0.13 (10.0.13, 10.0.1326.50504), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=6  IterationTime=200ms  
WarmupCount=4  

```
| Method               | Width | Count | Scenario | PresentPercent | Mean     | Error     | StdDev    | Op/s  | Gen0     | Gen1    | Allocated |
|--------------------- |------ |------ |--------- |--------------- |---------:|----------:|----------:|------:|---------:|--------:|----------:|
| ParseSharedSeparated | 16    | 4096  | array    | 100            | 3.644 ms | 0.1144 ms | 0.0297 ms | 274.4 | 250.0000 | 83.3333 |   2.38 MB |
